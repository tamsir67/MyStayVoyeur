import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Listing } from '../types';
import { 
  Calendar, Users, MapPin, ArrowRight, ShieldCheck, 
  X, CheckCircle2, CreditCard, Sparkles, AlertCircle, Leaf, Zap
} from 'lucide-react';

interface CalendarAvailabilityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CalendarAvailabilityModal: React.FC<CalendarAvailabilityModalProps> = ({ isOpen, onClose }) => {
  const { 
    listings, filters, setFilters, openCheckout, 
    setSelectedListing, isDateRangeBlocked, currentUser 
  } = useApp();

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const inThreeDays = new Date();
  inThreeDays.setDate(inThreeDays.getDate() + 3);

  const [startDate, setStartDate] = useState<string>(
    filters.startDate || tomorrow.toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState<string>(
    filters.endDate || inThreeDays.toISOString().split('T')[0]
  );
  const [guestsCount, setGuestsCount] = useState<number>(filters.guests || 2);
  const [selectedRegionFilter, setSelectedRegionFilter] = useState<string>('all');

  if (!isOpen) return null;

  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffDays = Math.max(1, Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
  const validDates = !isNaN(start.getTime()) && !isNaN(end.getTime()) && end > start;

  // Filter listings based on availability for chosen dates
  const publishedListings = listings.filter(l => l.status === 'publiee');
  
  const availableListings = publishedListings.filter(l => {
    // Check region filter
    if (selectedRegionFilter !== 'all' && l.region !== selectedRegionFilter) {
      return false;
    }
    // Check capacity
    if (l.capacity < guestsCount) {
      return false;
    }
    // Check if dates are blocked
    if (validDates) {
      const blockCheck = isDateRangeBlocked(l.id, startDate, endDate);
      if (blockCheck.isBlocked) return false;
      if (diffDays < l.minNights) return false;
    }
    return true;
  });

  const handleBookListing = (listing: Listing) => {
    // Update global search filters with selected dates
    setFilters(prev => ({
      ...prev,
      startDate,
      endDate,
      guests: guestsCount
    }));

    onClose();

    // Directly open Stripe Checkout with preselected dates
    openCheckout(listing, {
      startDate,
      endDate,
      guestsCount
    });
  };

  const handleViewListingDetails = (listing: Listing) => {
    setFilters(prev => ({
      ...prev,
      startDate,
      endDate,
      guests: guestsCount
    }));
    onClose();
    setSelectedListing(listing);
  };

  const regionsList = [
    { id: 'all', label: 'Toutes les régions' },
    { id: 'Bretagne', label: 'Bretagne' },
    { id: 'Normandie', label: 'Normandie' },
    { id: 'Auvergne-Rhône-Alpes', label: 'Auvergne & Cantal' },
    { id: 'Grand Est', label: 'Vosges' },
    { id: 'Nouvelle-Aquitaine', label: 'Périgord & Creuse' },
    { id: 'Occitanie', label: 'Cévennes & Larzac' },
    { id: 'Bourgogne-Franche-Comté', label: 'Morvan' },
    { id: "Provence-Alpes-Côte d'Azur", label: 'Luberon' },
    { id: 'Centre-Val de Loire', label: 'Sologne' },
    { id: 'Corse', label: 'Corse' },
    { id: 'Hauts-de-France', label: 'Baie de Somme' }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex justify-center items-start pt-12 sm:pt-16 pb-12 px-3 sm:px-4 md:px-6 animate-in fade-in duration-200">
      <div 
        id="calendar-availability-popup"
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col mb-auto animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-stone-200 flex items-start sm:items-center justify-between bg-[#FAF9F5] sticky top-0 z-20 gap-3">
          <div className="flex items-start sm:items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-br from-[#243E36] to-[#162722] text-[#A3E5C8] flex items-center justify-center shadow-xs shrink-0 mt-0.5 sm:mt-0">
              <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-serif font-bold text-sm sm:text-lg text-stone-900 leading-tight">
                  Calendrier des séjours & Disponibilités
                </h3>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Direct
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-stone-500 mt-0.5 line-clamp-2 sm:line-clamp-none">
                Bonjour {currentUser?.name ? currentUser.name.split(' ')[0] : ''} ! Sélectionnez vos dates pour visualiser les gîtes disponibles et réserver.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400 hover:text-stone-700 transition cursor-pointer shrink-0"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Date Selector Banner */}
        <div className="p-3.5 sm:p-5 bg-gradient-to-b from-[#FAF9F5] to-white border-b border-stone-200 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
            
            {/* Arrivée */}
            <div className="sm:col-span-4 bg-white p-3 rounded-2xl border border-stone-300 shadow-2xs">
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#243E36]" />
                <span>Date d'arrivée</span>
              </label>
              <input
                id="cal-modal-start-date"
                type="date"
                value={startDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={e => setStartDate(e.target.value)}
                className="w-full text-xs font-bold text-stone-900 bg-transparent outline-none cursor-pointer"
              />
            </div>

            {/* Départ */}
            <div className="sm:col-span-4 bg-white p-3 rounded-2xl border border-stone-300 shadow-2xs">
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#243E36]" />
                <span>Date de départ</span>
              </label>
              <input
                id="cal-modal-end-date"
                type="date"
                value={endDate}
                min={startDate || new Date().toISOString().split('T')[0]}
                onChange={e => setEndDate(e.target.value)}
                className="w-full text-xs font-bold text-stone-900 bg-transparent outline-none cursor-pointer"
              />
            </div>

            {/* Voyageurs */}
            <div className="sm:col-span-4 bg-white p-3 rounded-2xl border border-stone-300 shadow-2xs">
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-[#243E36]" />
                <span>Voyageurs</span>
              </label>
              <select
                id="cal-modal-guests-select"
                value={guestsCount}
                onChange={e => setGuestsCount(Number(e.target.value))}
                className="w-full text-xs font-bold text-stone-900 bg-transparent outline-none cursor-pointer"
              >
                <option value={1}>1 voyageur</option>
                <option value={2}>2 voyageurs</option>
                <option value={3}>3 voyageurs</option>
                <option value={4}>4 voyageurs</option>
                <option value={5}>5 voyageurs et +</option>
              </select>
            </div>

          </div>

          {/* Quick Info & Region Chips */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-stone-700">
                Durée sélectionnée :
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-[#243E36] text-white font-bold text-[11px]">
                {validDates ? `${diffDays} nuit${diffDays > 1 ? 's' : ''}` : 'Dates invalides'}
              </span>
              <span className="text-stone-400">•</span>
              <span className="text-stone-600 font-medium">
                {availableListings.length} site{availableListings.length > 1 ? 's' : ''} libre{availableListings.length > 1 ? 's' : ''} à ces dates
              </span>
            </div>

            {/* Region Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto max-w-full py-0.5">
              <span className="text-[11px] text-stone-400 font-semibold shrink-0">Filtrer région :</span>
              <select
                value={selectedRegionFilter}
                onChange={e => setSelectedRegionFilter(e.target.value)}
                className="text-xs p-1.5 rounded-xl border border-stone-200 bg-white font-semibold text-stone-800 outline-none cursor-pointer"
              >
                {regionsList.map(r => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Available Listings Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto max-h-[60vh] space-y-4">
          {availableListings.length === 0 ? (
            <div className="text-center py-12 bg-stone-50 rounded-2xl border border-dashed border-stone-300 p-6 space-y-3">
              <Calendar className="w-8 h-8 text-stone-400 mx-auto" />
              <h4 className="font-serif font-bold text-stone-800 text-base">
                Aucun hébergement disponible pour cette période exacte
              </h4>
              <p className="text-xs text-stone-500 max-w-md mx-auto">
                Modifiez vos dates d'arrivée ou de départ ci-dessus pour découvrir d'autres hébergements ruraux disponibles.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availableListings.map(listing => {
                const nightlyTotal = listing.pricePerNight * diffDays;
                const grandEstimated = nightlyTotal + listing.cleaningFee + Number((nightlyTotal * 0.12).toFixed(2)) + Number((diffDays * guestsCount * 1.5).toFixed(2));

                return (
                  <div
                    key={listing.id}
                    className="bg-white rounded-2xl border border-stone-200 hover:border-[#243E36] overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between p-3.5 space-y-3"
                  >
                    <div className="flex gap-3">
                      <img
                        src={listing.images[0] || 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=400&q=80'}
                        alt={listing.title}
                        className="w-24 h-24 rounded-xl object-cover shrink-0 cursor-pointer"
                        onClick={() => handleViewListingDetails(listing)}
                      />
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[10px] uppercase font-bold text-stone-500 truncate">
                            {listing.propertyType.replace('_', ' ')}
                          </span>
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 shrink-0">
                            Disponible ✓
                          </span>
                        </div>
                        <h4 
                          onClick={() => handleViewListingDetails(listing)}
                          className="font-serif font-bold text-xs sm:text-sm text-stone-900 hover:text-[#243E36] cursor-pointer line-clamp-1"
                        >
                          {listing.title}
                        </h4>
                        <div className="text-[11px] text-stone-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#8C5E45]" />
                          <span>{listing.commune} ({listing.department})</span>
                        </div>
                        <div className="text-[11px] text-stone-600 font-semibold pt-0.5">
                          {listing.pricePerNight} € <span className="font-normal text-stone-400">/ nuit</span> • Min. {listing.minNights} n.
                        </div>
                      </div>
                    </div>

                    {/* Bottom Pricing & Action */}
                    <div className="pt-2 border-t border-stone-100 flex flex-col xs:flex-row xs:items-center justify-between gap-2.5">
                      <div>
                        <div className="text-[11px] text-stone-400">
                          Total estimé ({diffDays} n.) :
                        </div>
                        <div className="font-bold text-sm text-[#243E36]">
                          {grandEstimated.toFixed(2)} € TTC
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 w-full xs:w-auto">
                        <button
                          type="button"
                          onClick={() => handleViewListingDetails(listing)}
                          className="flex-1 xs:flex-initial px-3 py-2 rounded-xl border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-semibold transition cursor-pointer text-center"
                        >
                          Détails
                        </button>
                        <button
                          type="button"
                          onClick={() => handleBookListing(listing)}
                          className="flex-2 xs:flex-initial px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#243E36] to-[#162722] hover:from-[#1b302a] hover:to-[#0f1d18] text-white text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                        >
                          <CreditCard className="w-3.5 h-3.5 text-[#A3E5C8]" />
                          <span>Réserver et payer</span>
                          <ArrowRight className="w-3 h-3 text-[#A3E5C8]" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-6 py-3.5 bg-[#FAF9F5] border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-stone-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Paiement sécurisé par carte bancaire avec Stripe Connect • Annulation modérée ou flexible</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-semibold text-stone-600 hover:text-stone-900 underline cursor-pointer"
          >
            Fermer le calendrier
          </button>
        </div>

      </div>
    </div>
  );
};
