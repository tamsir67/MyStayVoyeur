// Enregistrement du Service Worker (PWA) — uniquement en production
export function registerServiceWorker() {
  if (!import.meta.env.PROD || typeof window === 'undefined' || !('serviceWorker' in navigator)) return;

  window.addEventListener('load', () => {
    const hadController = !!navigator.serviceWorker.controller;
    let reloading = false;

    // Quand une nouvelle version est déployée sur Vercel, on recharge une seule fois
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!hadController || reloading) return;
      reloading = true;
      window.location.reload();
    });

    navigator.serviceWorker
      .register('/sw.js', { scope: '/' })
      .then((reg) => {
        // Vérifie les mises à jour quand l'utilisateur revient sur l'application
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') reg.update().catch(() => {});
        });
      })
      .catch((err) => console.warn('Service Worker non enregistré :', err));
  });
}

// Utilisé par l'écran d'erreur : vide le cache PWA et désinstalle le Service Worker
export async function clearPwaCaches() {
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
  } catch {
    /* ignore */
  }
}
