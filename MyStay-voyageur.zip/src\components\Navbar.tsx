import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Compass, Calendar, Home, ShieldCheck, 
  Heart, Check, LogIn, LogOut, UserPlus, 
  ChevronDown, User as UserIcon, Camera, MessageSquare,
  Database, RefreshCw, Menu, X
} from 'lucide-react';
import { UserRole } from '../types';
import { LogoMyStayVoyager } from './LogoMyStayVoyager';

export const Navbar: React.FC = () => {
  const { 
    currentUser, switchRole, activeView, setActiveView, 
    favorites, bookings, isAuthenticated, logout, openAuthModal, 
    requireAuth, openProfileModal, setActiveChatBookingId, showNotification, 
    unreadMessagesCount, openAirtableModal
  } = useApp();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const travelerActiveBookings = bookings.filter(
    b => b.travelerId === currentUser.id && (b.status === 'confirmee' || b.status === 'en_attente_hote')
  );

  const roles: { id: UserRole; label: string; badge: string; desc: string }[] = [
    { id: 'voyageur', label: 'Voyageur', badge: 'bg-emerald-100 text-emerald-800 border-emerald-300', desc: 'Recherche, réservation & séjours' },
    { id: 'hote', label: 'Hôte rural', badge: 'bg-amber-100 text-amber-800 border-amber-300', desc: 'Gestion de gîtes, calendrier & revenus' },
    { id: 'moderateur', label: 'Modérateur', badge: 'bg-indigo-100 text-indigo-800 border-indigo-300', desc: 'Superviseur hôtes et voyageurs, médiation & arbitrage' },
    { id: 'admin', label: 'Super Admin', badge: 'bg-stone-800 text-stone-100 border-stone-700', desc: 'Contrôle total, attributions de rôles & configuration' }
  ];

  const handleNavClick = (view: 'my_trips' | 'host_space' | 'admin_space', targetRole?: UserRole) => {
    if (!isAuthenticated) {
      openAuthModal('login', view);
      return;
    }
    if (targetRole && currentUser.role !== targetRole && currentUser.role !== 'admin' && currentUser.role !== 'moderateur') {
      switchRole(targetRole);
    }
    setActiveView(view);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F5] border-b border-[#E6E4DD] backdrop-blur-md bg-opacity-95 shadow-xs">
      {/* Top Accent Band */}
      <div className="w-full h-2 bg-[#243E36] border-b border-[#1A2E28]" />

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo Brand My Stay Voyager */}
          <div 
            id="brand-logo-btn"
            onClick={() => setActiveView('explore')}
            className="flex items-center cursor-pointer group"
          >
            <LogoMyStayVoyager variant="horizontal" size="md" />
          </div>

          {/* Navigation Links avec filtrage strict par rôle utilisateur (Inspiré de Booking.com) */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              id="nav-explore-btn"
              onClick={() => setActiveView('explore')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                activeView === 'explore'
                  ? 'text-[#243E36] bg-[#EAE8DF]'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span>Explorer</span>
            </button>

            {/* Pour les visiteurs non connectés : bouton pro style Booking.com */}
            {!isAuthenticated && (
              <button
                id="nav-become-host-btn"
                onClick={() => openAuthModal('signup')}
                className="px-3 py-2 rounded-lg text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-[#F3F1E9] transition cursor-pointer flex items-center gap-1.5"
                title="Mettre votre hébergement rural sur MyStay"
              >
                <Home className="w-4 h-4 text-[#8C5E45]" />
                <span>Mettre mon hébergement sur MyStay</span>
              </button>
            )}

            {/* VOYAGEUR CONNECTÉ : Ne voit QUE ses voyages */}
            {isAuthenticated && currentUser.role === 'voyageur' && (
              <button
                id="nav-trips-btn"
                onClick={() => setActiveView('my_trips')}
                title="Gérer mes réservations & séjours"
                className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                  activeView === 'my_trips'
                    ? 'text-[#243E36] bg-[#EAE8DF] font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Mes Voyages</span>
                {travelerActiveBookings.length > 0 && (
                  <span className="ml-1 w-5 h-5 rounded-full bg-[#8C5E45] text-white text-xs flex items-center justify-center font-bold">
                    {travelerActiveBookings.length}
                  </span>
                )}
              </button>
            )}

            {/* HÔTE CONNECTÉ : Ne voit QUE son espace hébergement */}
            {isAuthenticated && currentUser.role === 'hote' && (
              <button
                id="nav-host-btn"
                onClick={() => setActiveView('host_space')}
                title="Gérer mes hébergements, réservations et calendrier"
                className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                  activeView === 'host_space'
                    ? 'text-[#243E36] bg-[#EAE8DF] font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                }`}
              >
                <Home className="w-4 h-4 text-amber-800" />
                <span>Mes Hébergements & Calendrier</span>
              </button>
            )}

            {/* MODÉRATEUR : Superviseur entre Hôte et Voyageur */}
            {isAuthenticated && currentUser.role === 'moderateur' && (
              <>
                <button
                  id="nav-moderator-trips-btn"
                  onClick={() => setActiveView('my_trips')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'my_trips'
                      ? 'text-[#243E36] bg-[#EAE8DF]'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                  }`}
                  title="Supervision de toutes les réservations voyageurs"
                >
                  <Calendar className="w-4 h-4 text-indigo-700" />
                  <span>Voyages (Supervision)</span>
                </button>

                <button
                  id="nav-moderator-host-btn"
                  onClick={() => setActiveView('host_space')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'host_space'
                      ? 'text-[#243E36] bg-[#EAE8DF]'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                  }`}
                  title="Supervision de tous les hébergements hôtes"
                >
                  <Home className="w-4 h-4 text-indigo-700" />
                  <span>Hôtes (Supervision)</span>
                </button>

                <button
                  id="nav-moderator-supervision-btn"
                  onClick={() => setActiveView('admin_space')}
                  title="Superviser les hôtes et voyageurs, arbitrer les séjours"
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'admin_space'
                      ? 'text-indigo-900 bg-indigo-100 font-bold border border-indigo-200 shadow-2xs'
                      : 'text-indigo-700 hover:text-indigo-900 hover:bg-indigo-50'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Supervision & Médiation</span>
                  <span className="text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full font-bold">Modérateur</span>
                </button>
              </>
            )}

            {/* SUPER ADMIN : Plein pouvoir sur tout le monde */}
            {isAuthenticated && currentUser.role === 'admin' && (
              <>
                <button
                  id="nav-admin-trips-btn"
                  onClick={() => setActiveView('my_trips')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'my_trips' ? 'text-[#243E36] bg-[#EAE8DF]' : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  <span>Voyages</span>
                </button>

                <button
                  id="nav-admin-host-btn"
                  onClick={() => setActiveView('host_space')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'host_space' ? 'text-[#243E36] bg-[#EAE8DF]' : 'text-stone-600 hover:text-stone-900 hover:bg-[#F3F1E9]'
                  }`}
                >
                  <Home className="w-4 h-4" />
                  <span>Hôtes</span>
                </button>

                <button
                  id="nav-super-admin-btn"
                  onClick={() => setActiveView('admin_space')}
                  title="Plein pouvoir, attributions de rôles, CMS & Configuration système"
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    activeView === 'admin_space'
                      ? 'text-stone-900 bg-stone-200 font-bold border border-stone-300 shadow-2xs'
                      : 'text-stone-700 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Super Admin</span>
                  <span className="text-[10px] bg-stone-900 text-white px-1.5 py-0.5 rounded-full font-bold">Plein pouvoir</span>
                </button>
              </>
            )}
          </nav>

          {/* Right Controls: Favorites, Airtable (Super Admin only), Messages, Auth */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Airtable Sync Button - Réservé STRICTEMENT au Super Admin */}
            {isAuthenticated && currentUser.role === 'admin' && (
              <button
                id="nav-airtable-sync-btn"
                onClick={openAirtableModal}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-[#18392b] bg-[#e6ede9] hover:bg-[#d8e4dd] border border-[#a8ccbc] transition cursor-pointer shadow-xs group"
                title="Synchronisation Base de Données Airtable (appIt4PVIpjgrmhri - Réservé Super Admin)"
              >
                <Database className="w-3.5 h-3.5 text-emerald-700 group-hover:scale-110 transition-transform shrink-0" />
                <span className="font-mono text-xs hidden sm:inline">Airtable</span>
                <span className="text-[10px] bg-[#243E36] text-[#A3E5C8] px-1.5 py-0.5 rounded-md font-sans font-semibold">Sync</span>
              </button>
            )}

            {/* Messages Icon */}
            <button
              id="nav-messages-btn"
              onClick={() => {
                const myConvs = bookings.filter(b => b.travelerId === currentUser.id || b.hostId === currentUser.id);
                if (myConvs.length > 0) {
                  setActiveChatBookingId(myConvs[0].id);
                } else if (bookings.length > 0) {
                  setActiveChatBookingId(bookings[0].id);
                } else {
                  showNotification('Messagerie Instantanée', 'Sélectionnez un hébergement ou une réservation pour discuter en direct.', 'info');
                }
              }}
              className="relative p-2 text-stone-600 hover:text-[#243E36] hover:bg-[#F3F1E9] rounded-lg transition cursor-pointer"
              title="Messagerie instantanée MyStay"
            >
              <MessageSquare className="w-5 h-5" />
              {unreadMessagesCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-emerald-600 text-white text-[10px] rounded-full flex items-center justify-center font-bold animate-pulse">
                  {unreadMessagesCount}
                </span>
              )}
            </button>

            {/* Favorites Icon (accessible aux voyageurs et curieux) */}
            {(!isAuthenticated || currentUser.role === 'voyageur' || currentUser.role === 'admin') && (
              <button
                id="nav-favorites-btn"
                onClick={() => setActiveView('my_trips')}
                className="relative p-2 text-stone-600 hover:text-rose-600 hover:bg-[#F3F1E9] rounded-lg transition cursor-pointer"
                title="Mes hébergements favoris"
              >
                <Heart className={`w-5 h-5 ${favorites.length > 0 ? 'text-rose-600 fill-rose-600' : ''}`} />
                {favorites.length > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-600 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                    {favorites.length}
                  </span>
                )}
              </button>
            )}

            {/* Authentication Buttons OR User Profile */}
            {!isAuthenticated ? (
              <div className="flex items-center gap-2 pl-2 border-l border-stone-300">
                <button
                  id="nav-login-btn"
                  onClick={() => openAuthModal('login')}
                  className="px-3.5 py-1.5 text-xs sm:text-sm font-semibold text-[#243E36] hover:bg-[#EAE8DF] rounded-xl transition flex items-center gap-1.5 cursor-pointer border border-[#243E36]/30"
                  title="Se connecter à votre compte"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Connexion</span>
                </button>
                <button
                  id="nav-signup-btn"
                  onClick={() => openAuthModal('signup')}
                  className="hidden sm:flex px-3.5 py-1.5 text-xs sm:text-sm font-semibold bg-[#243E36] hover:bg-[#1A2E28] text-white rounded-xl shadow-xs transition items-center gap-1.5 cursor-pointer"
                  title="Créer un compte MyStay"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Inscription</span>
                </button>
              </div>
            ) : (
              <div className="relative pl-2 border-l border-stone-300">
                <button
                  id="nav-user-menu-btn"
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1 rounded-xl hover:bg-[#EAE8DF] transition cursor-pointer"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    referrerPolicy="no-referrer"
                    className="w-9 h-9 rounded-full object-cover border-2 border-[#243E36]"
                  />
                  <div className="hidden sm:block text-left">
                    <div className="text-xs font-semibold text-stone-900 leading-tight">
                      Bienvenue {currentUser.name.split(' ')[0] || currentUser.name}
                    </div>
                    <div className="text-[11px] text-stone-500">
                      {currentUser.role === 'admin' ? 'Super Administrateur' : currentUser.role === 'moderateur' ? 'Modérateur / Superviseur' : currentUser.role === 'hote' ? 'Hôte rural' : 'Voyageur'}
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-500 hidden sm:block" />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsUserMenuOpen(false)} 
                    />
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-stone-200 py-1 z-50 text-sm">
                      <div 
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          openProfileModal();
                        }}
                        className="px-4 py-3 border-b border-stone-100 flex items-center gap-3 cursor-pointer hover:bg-stone-50 transition group"
                        title="Cliquer pour voir et modifier mon profil"
                      >
                        <div className="relative shrink-0">
                          <img
                            src={currentUser.avatar}
                            alt={currentUser.name}
                            referrerPolicy="no-referrer"
                            className="w-11 h-11 rounded-full object-cover border border-[#243E36] shadow-sm group-hover:brightness-95 transition"
                          />
                          <span className="absolute -bottom-1 -right-1 p-0.5 bg-[#243E36] text-[#A3E5C8] rounded-full shadow-xs">
                            <Camera className="w-2.5 h-2.5" />
                          </span>
                        </div>
                        <div className="overflow-hidden flex-1">
                          <div className="font-semibold text-stone-900 truncate group-hover:text-[#243E36] flex items-center justify-between">
                            <span>Bienvenue {currentUser.name.split(' ')[0] || currentUser.name}</span>
                            <span className="text-[10px] text-stone-400 group-hover:text-emerald-700 font-normal">Modifier</span>
                          </div>
                          <div className="text-xs text-stone-500 truncate">{currentUser.email || 'Mode Démo'}</div>
                          <span className={`inline-block mt-1 px-2 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wider ${
                            currentUser.role === 'admin' ? 'bg-stone-900 text-white' :
                            currentUser.role === 'moderateur' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                            currentUser.role === 'hote' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                            'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}>
                            {currentUser.role === 'admin' ? 'Super Admin (Plein Pouvoir)' : currentUser.role === 'moderateur' ? 'Superviseur & Médiateur' : currentUser.role === 'hote' ? 'Hôte rural' : 'Voyageur'}
                          </span>
                        </div>
                      </div>

                      <div className="py-1">
                        <button
                          id="nav-user-profile-btn"
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            openProfileModal();
                          }}
                          className="w-full text-left px-4 py-2 text-[#243E36] bg-emerald-50/50 hover:bg-emerald-100/60 font-medium flex items-center gap-2 cursor-pointer transition"
                        >
                          <Camera className="w-4 h-4 text-emerald-700" />
                          <span>Mon Profil & Photo</span>
                        </button>

                        <button
                          id="nav-user-menu-space-btn"
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            setActiveView(currentUser.role === 'admin' || currentUser.role === 'moderateur' ? 'admin_space' : currentUser.role === 'hote' ? 'host_space' : 'my_trips');
                          }}
                          className="w-full text-left px-4 py-2 text-stone-700 hover:bg-stone-50 flex items-center gap-2 cursor-pointer"
                        >
                          <UserIcon className="w-4 h-4 text-stone-500" />
                          <span>
                            {currentUser.role === 'admin' ? 'Console Super Admin (Attributions & CMS)' :
                             currentUser.role === 'moderateur' ? 'Espace Supervision & Médiation' :
                             currentUser.role === 'hote' ? `Bienvenue ${currentUser.name.split(' ')[0]} (Hébergements)` : `Bienvenue ${currentUser.name.split(' ')[0]} (Mes Voyages)`}
                          </span>
                        </button>

                        {/* Lien Airtable dans le menu : RÉSERVÉ STRICTEMENT AU SUPER ADMIN */}
                        {isAuthenticated && currentUser.role === 'admin' && (
                          <button
                            id="nav-user-menu-airtable-btn"
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              openAirtableModal();
                            }}
                            className="w-full text-left px-4 py-2 text-[#18392b] bg-emerald-50/70 hover:bg-emerald-100/70 flex items-center gap-2 cursor-pointer font-medium transition"
                          >
                            <Database className="w-4 h-4 text-emerald-700" />
                            <span>Base Airtable (appIt4PVIpjgrmhri)</span>
                          </button>
                        )}
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            openAuthModal('forgot');
                          }}
                          className="w-full text-left px-4 py-2 text-stone-700 hover:bg-stone-50 flex items-center gap-2 cursor-pointer"
                        >
                          <ShieldCheck className="w-4 h-4 text-stone-500" />
                          <span>Changer de mot de passe</span>
                        </button>
                      </div>

                      {/* Sélecteur de profil Démo : STRICTEMENT RÉSERVÉ au Super Admin pour tester les rôles */}
                      {isAuthenticated && currentUser.role === 'admin' && (
                        <div className="border-t border-stone-100 p-2 bg-stone-50/80">
                          <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider px-2 py-1 flex items-center justify-between">
                            <span>Changer de profil (Test Super Admin)</span>
                            <span className="text-[9px] bg-stone-200 text-stone-700 px-1.5 py-0.5 rounded font-mono">Admin Only</span>
                          </div>
                          <div className="grid grid-cols-2 gap-1 mt-1">
                            {roles.map(r => (
                              <button
                                key={r.id}
                                id={`role-switch-${r.id}`}
                                onClick={() => {
                                  setIsUserMenuOpen(false);
                                  switchRole(r.id);
                                }}
                                className={`px-2 py-1.5 text-[11px] rounded-lg text-left font-medium transition cursor-pointer flex items-center gap-1 ${
                                  currentUser.role === r.id
                                    ? 'bg-[#243E36] text-white font-bold shadow-xs'
                                    : 'hover:bg-white text-stone-700'
                                }`}
                                title={r.desc}
                              >
                                <span className="truncate">{r.label}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="border-t border-stone-100 pt-1">
                        <button
                          id="nav-logout-btn"
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            logout();
                          }}
                          className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 flex items-center gap-2 font-medium"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Se déconnecter</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Mobile Hamburger Toggle Button */}
            <button
              id="nav-mobile-toggle-btn"
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-stone-700 hover:text-[#243E36] hover:bg-[#EAE8DF] rounded-xl transition cursor-pointer"
              title={isMobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu de navigation"}
              aria-label="Menu principal"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>

        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {isMobileMenuOpen && (
        <div 
          id="nav-mobile-drawer"
          className="lg:hidden border-t border-stone-200 bg-[#FAF9F5] px-4 py-4 space-y-3 animate-in slide-in-from-top-2 duration-200 shadow-lg max-h-[85vh] overflow-y-auto"
        >
          {/* User Status Card if Authenticated */}
          {isAuthenticated && (
            <div className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-stone-200 shadow-2xs">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover border-2 border-[#243E36]"
              />
              <div className="min-w-0 flex-1">
                <div className="font-bold text-xs text-stone-900 truncate">
                  {currentUser.name}
                </div>
                <div className="text-[11px] text-stone-500 truncate">
                  {currentUser.email}
                </div>
                <span className={`inline-block mt-0.5 px-2 py-0.2 text-[9px] font-bold rounded-full uppercase tracking-wider ${
                  currentUser.role === 'admin' ? 'bg-stone-900 text-white' :
                  currentUser.role === 'moderateur' ? 'bg-indigo-100 text-indigo-800' :
                  currentUser.role === 'hote' ? 'bg-amber-100 text-amber-800' :
                  'bg-emerald-100 text-emerald-800'
                }`}>
                  {currentUser.role === 'admin' ? 'Super Admin' : currentUser.role === 'moderateur' ? 'Modérateur' : currentUser.role === 'hote' ? 'Hôte rural' : 'Voyageur'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  openProfileModal();
                }}
                className="p-2 text-[#243E36] hover:bg-emerald-50 rounded-xl border border-emerald-200 transition text-xs font-semibold shrink-0"
                title="Gérer mon profil"
              >
                <Camera className="w-4 h-4 text-emerald-700" />
              </button>
            </div>
          )}

          {/* Navigation Items */}
          <div className="space-y-1.5">
            <button
              onClick={() => {
                setActiveView('explore');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                activeView === 'explore'
                  ? 'bg-[#243E36] text-white shadow-xs'
                  : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
              }`}
            >
              <span className="flex items-center gap-2">
                <Compass className="w-4 h-4" />
                <span>Explorer les hébergements</span>
              </span>
            </button>

            {/* If Voyageur */}
            {(currentUser.role === 'voyageur' || currentUser.role === 'admin') && (
              <button
                onClick={() => {
                  handleNavClick('my_trips', 'voyageur');
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                  activeView === 'my_trips'
                    ? 'bg-[#243E36] text-white shadow-xs'
                    : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-700" />
                  <span>Mes Voyages & Réservations</span>
                </span>
                {travelerActiveBookings.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-black text-[10px] font-bold">
                    {travelerActiveBookings.length}
                  </span>
                )}
              </button>
            )}

            {/* If Hôte */}
            {(currentUser.role === 'hote' || currentUser.role === 'admin') && (
              <button
                onClick={() => {
                  handleNavClick('host_space', 'hote');
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                  activeView === 'host_space'
                    ? 'bg-[#243E36] text-white shadow-xs'
                    : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Home className="w-4 h-4 text-amber-700" />
                  <span>Mes Hébergements & Calendrier</span>
                </span>
              </button>
            )}

            {/* If Modérateur */}
            {currentUser.role === 'moderateur' && (
              <button
                onClick={() => {
                  setActiveView('admin_space');
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                  activeView === 'admin_space'
                    ? 'bg-indigo-900 text-white shadow-xs'
                    : 'bg-white hover:bg-stone-100 text-indigo-950 border border-indigo-200'
                }`}
              >
                <span className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Supervision & Médiation</span>
                </span>
                <span className="text-[10px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full font-bold">Modérateur</span>
              </button>
            )}

            {/* If Super Admin */}
            {currentUser.role === 'admin' && (
              <>
                <button
                  onClick={() => {
                    setActiveView('admin_space');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                    activeView === 'admin_space'
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'bg-white hover:bg-stone-100 text-stone-900 border border-stone-300'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Console Super Admin (CRUD CMS)</span>
                  </span>
                  <span className="text-[10px] bg-stone-800 text-white px-2 py-0.5 rounded-full font-bold">Admin</span>
                </button>

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openAirtableModal();
                  }}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold bg-[#e6ede9] hover:bg-[#d8e4dd] text-[#18392b] border border-[#a8ccbc] transition cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-700" />
                    <span>Synchronisation Airtable (appIt4...)</span>
                  </span>
                  <span className="text-[10px] bg-[#243E36] text-[#A3E5C8] px-2 py-0.5 rounded-md font-semibold">Sync</span>
                </button>
              </>
            )}

            {/* Become Host for visitors */}
            {!isAuthenticated && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  openAuthModal('signup');
                }}
                className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition"
              >
                <Home className="w-4 h-4 text-amber-800" />
                <span>Mettre mon hébergement sur MyStay</span>
              </button>
            )}
          </div>

          {/* Role switcher for Admin Demo on mobile */}
          {isAuthenticated && currentUser.role === 'admin' && (
            <div className="p-3 bg-stone-100 rounded-2xl border border-stone-200 space-y-1.5">
              <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block">
                Test multi-rôles (Admin) :
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {roles.map(r => (
                  <button
                    key={r.id}
                    onClick={() => {
                      switchRole(r.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                      currentUser.role === r.id
                        ? 'bg-[#243E36] text-white'
                        : 'bg-white text-stone-700 hover:bg-stone-50 border border-stone-200'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Auth Action Buttons */}
          <div className="pt-2 border-t border-stone-200 flex flex-col gap-2">
            {!isAuthenticated ? (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openAuthModal('login');
                  }}
                  className="w-full py-2.5 px-3 rounded-xl border border-[#243E36] text-[#243E36] font-bold text-xs flex items-center justify-center gap-1.5 bg-white shadow-2xs hover:bg-[#EAE8DF] transition cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Connexion</span>
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openAuthModal('signup');
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#243E36] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-2xs hover:bg-[#1A2E28] transition cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Inscription</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  logout();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-red-50 text-red-700 hover:bg-red-100 font-bold text-xs flex items-center justify-center gap-1.5 transition border border-red-200 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Se déconnecter de MyStay</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

