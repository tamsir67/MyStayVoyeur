import type { VercelRequest, VercelResponse } from '@vercel/node';
import { app } from '../server/app';

// Vercel Serverless Function entry point
export default function handler(req: VercelRequest, res: VercelResponse) {
  try {
    return app(req as any, res as any);
  } catch (err: any) {
    console.error('Erreur non gérée Vercel Serverless:', err);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: err?.message || 'Erreur interne de la fonction Vercel'
      });
    }
  }
}

export { app };
