import 'dotenv/config';
import express from 'express';
import path from 'path';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { app } from './server/app';
import { setupChatWebSocket } from './server/chatSocket';

async function startServer() {
  const PORT = 3000;
  const httpServer = http.createServer(app);

  // 2. WEBSOCKET REAL-TIME MESSAGING
  setupChatWebSocket(httpServer);

  // 3. FRONTEND INTEGRATION & VITE MIDDLEWARE
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Serveur MyStay (Backend Express + Frontend Vite + WebSocket Chat) démarré sur http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Erreur au démarrage du serveur:', err);
});
