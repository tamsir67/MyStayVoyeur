/* MyStay Voyager — Service Worker (PWA)
 * - Pages : réseau d'abord, repli sur la version en cache (mode hors ligne)
 * - Fichiers compilés /assets/* (noms hachés) : cache d'abord
 * - Images, icônes, polices : cache avec mise à jour en arrière-plan
 * - API (/api, /airtable), WebSocket, requêtes non-GET et domaines tiers : jamais mis en cache
 */
const VERSION = 'mystay-v1';
const SHELL_CACHE = `${VERSION}-shell`;
const ASSET_CACHE = `${VERSION}-assets`;
const RUNTIME_CACHE = `${VERSION}-runtime`;
const SHELL_URLS = ['/', '/index.html', '/offline.html', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png', '/logo.jpg'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then((cache) => Promise.allSettled(SHELL_URLS.map((u) => cache.add(new Request(u, { cache: 'reload' })))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
  if (event.data === 'CLEAR_CACHES') {
    event.waitUntil(caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k)))));
  }
});

const isFont = (url) => url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Ne jamais intercepter les données dynamiques ni les domaines tiers (sauf polices)
  if (url.origin === self.location.origin) {
    if (url.pathname.startsWith('/api') || url.pathname.startsWith('/airtable') || url.pathname.startsWith('/ws')) return;
  } else if (!isFont(url)) {
    return;
  }

  // Navigation (pages HTML) : réseau d'abord
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL_CACHE).then((c) => c.put('/index.html', copy));
          return res;
        })
        .catch(async () => (await caches.match('/index.html')) || (await caches.match('/offline.html')) || Response.error())
    );
    return;
  }

  // Fichiers compilés avec hash : immuables, cache d'abord
  if (url.origin === self.location.origin && /^\/assets\/.+-[\w-]{6,}\.(js|css|woff2?|png|jpe?g|svg|webp)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then((hit) => hit || fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(ASSET_CACHE).then((c) => c.put(req, copy)); }
        return res;
      }))
    );
    return;
  }

  // Images, icônes, manifeste, polices : stale-while-revalidate
  if (isFont(url) || /\.(png|jpe?g|webp|svg|ico|webmanifest)$/.test(url.pathname)) {
    event.respondWith(
      caches.open(RUNTIME_CACHE).then(async (cache) => {
        const hit = await cache.match(req);
        const net = fetch(req).then((res) => {
          if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
          return res;
        }).catch(() => hit);
        return hit || net;
      })
    );
  }
});
