import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  MessageCircle, X, Send, RotateCcw, Sparkles, 
  ChevronRight, Shield, Video, Camera, Home, 
  Leaf, Train, Phone, CheckCircle2, User as UserIcon,
  HelpCircle, Calendar, CreditCard, Compass
} from 'lucide-react';

const KOUMBA_AVATAR = '/koumba_avatar.jpg';

interface QuickAction {
  label: string;
  actionType: 'navigate' | 'modal' | 'topic';
  payload?: string;
}

interface BotMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  topicId?: string;
  quickActions?: QuickAction[];
}

interface PredefinedTopic {
  id: string;
  title: string;
  iconName: 'home' | 'video' | 'camera' | 'shield' | 'leaf' | 'train' | 'phone' | 'help' | 'user';
  botReply: string;
  actions?: QuickAction[];
}

const PREDEFINED_TOPICS: PredefinedTopic[] = [
  {
    id: 'qui_suis_je',
    title: '👤 Qui suis-je en ligne ?',
    iconName: 'user',
    botReply: `Je sais précisément qui est en ligne avec moi !`,
    actions: [
      { label: 'Voir mon profil', actionType: 'modal', payload: 'profile' },
      { label: 'Mes séjours', actionType: 'navigate', payload: 'my_trips' }
    ]
  },
  {
    id: 'deposer_annonce',
    title: '🏡 Déposer une annonce rurale',
    iconName: 'home',
    botReply: `Pour inscrire un hébergement sur MyStay, voici les étapes clés :\n\n1. **Éligibilité Terroir** : Votre gîte doit être situé dans une commune rurale (sélectionnable dans la liste synchronisée par région ou saisie personnalisée).\n2. **Charte Éco-responsable** : Vous devez valider au moins **3 pratiques durables** (énergie verte, tri/compost, circuits courts, gestion de l'eau, etc.).\n3. **Photos & Vidéos** : Vous pouvez intégrer vos photos et désormais ajouter un **lien vidéo de présentation** (YouTube, Vimeo ou fichier MP4) pour sublimer votre domaine !\n4. **Frais équitables** : Commission de 12% seulement pour financer le circuit éco-touristique.`,
    actions: [
      { label: 'Ouvrir l’Espace Hôte', actionType: 'navigate', payload: 'host' },
      { label: 'Voir comment ajouter une vidéo', actionType: 'topic', payload: 'video_annonce' }
    ]
  },
  {
    id: 'reservation_paiement',
    title: '💳 Réservation & Paiement sécurisé',
    iconName: 'leaf',
    botReply: `Tout est pensé pour un séjour serein et transparent :\n\n• **Modes de réservation** : Instantanée (confirmation immédiate) ou Sur demande (réponse de l'hôte sous 24h).\n• **Paiement Stripe** : Chiffrement bancaire SSL/TLS aux normes bancaires européennes. Aucun numéro de carte n'est stocké sur nos serveurs.\n• **Rémunération juste** : 88% du montant est directement versé aux propriétaires des gîtes et terroirs ruraux.\n• **Calcul d'impact** : Vous visualisez les kg de CO₂ économisés par rapport à une nuitée hôtelière conventionnelle.`,
    actions: [
      { label: 'Explorer les gîtes', actionType: 'navigate', payload: 'explore' },
      { label: 'Mobilité douce & trains', actionType: 'topic', payload: 'mobilite_douce' }
    ]
  },
  {
    id: 'video_annonce',
    title: '🎥 Ajouter une vidéo à un gîte',
    iconName: 'video',
    botReply: `Vous pouvez désormais enrichir chaque annonce d'une vidéo immersive de découverte !\n\n• **Dans le formulaire de dépôt (Étape 4 - Photos & Médias)** : un champ dédié vous permet de renseigner un lien **YouTube, Vimeo ou une vidéo MP4/WebM**, ou même d'importer un fichier direct depuis votre appareil.\n• **Visibilité maximale** : Un lecteur vidéo fluide est intégré sur la fiche détaillée avec un onglet dédié "Visite Vidéo", et un badge "Visite Vidéo" apparaît sur la carte de recherche pour attirer plus de voyageurs.`,
    actions: [
      { label: 'Accéder au formulaire d’annonce', actionType: 'navigate', payload: 'host' },
      { label: 'Autre question sur les annonces', actionType: 'topic', payload: 'deposer_annonce' }
    ]
  },
  {
    id: 'photo_profil',
    title: '📸 Photo de profil & Inscription',
    iconName: 'camera',
    botReply: `Personnalisez votre présence sur MyStay dès votre inscription :\n\n• **Fiche d'inscription** : Vous pouvez cliquer sur "Parcourir..." pour charger votre propre photo (JPG, PNG ou WebP jusqu'à 5 Mo), ou coller l'URL de votre choix.\n• **Avatars présélectionnés** : Vous pouvez également sélectionner en 1 clic un avatar de la communauté, comme le profil voyageur de Ba Tamsir !\n• **Protection RGPD** : Vos photos de profil et données personnelles sont strictement confidentielles, hébergées en Europe et protégées selon la loi européenne RGPD (Règlement UE 2016/679).`,
    actions: [
      { label: 'S’inscrire / Se connecter', actionType: 'modal', payload: 'auth' },
      { label: 'En savoir plus sur le RGPD', actionType: 'topic', payload: 'rgpd_protection' }
    ]
  },
  {
    id: 'rgpd_protection',
    title: '🛡️ Protection des données & RGPD',
    iconName: 'shield',
    botReply: `Sur MyStay, la protection de votre vie privée est une priorité absolue :\n\n• **Conformité stricte au RGPD (Règlement UE 2016/679)** : Vos informations personnelles, documents d'identité, coordonnées et photos de profil sont rigoureusement protégés.\n• **Souveraineté européenne** : Toutes vos données sont hébergées sur des serveurs sécurisés situés dans l'Union Européenne.\n• **Zéro revente commerciale** : Nous ne cédons ni ne vendons jamais vos données à des régies publicitaires ou tiers.\n• **Vos droits** : Vous bénéficiez d'un droit d'accès, de rectification, de portabilité et à l'oubli à tout moment auprès de notre DPO (dpo@mystay-rural.fr).`,
    actions: [
      { label: 'Lire les mentions du Footer', actionType: 'modal', payload: 'rgpd' },
      { label: 'Poser une autre question', actionType: 'topic', payload: 'menu' }
    ]
  },
  {
    id: 'mobilite_douce',
    title: '🚲 Mobilité douce & Gares rurales',
    iconName: 'train',
    botReply: `Favoriser les voyages bas carbone fait partie de l'ADN de MyStay :\n\n• **Accès train** : Chaque hébergement indique la gare SNCF la plus proche (Florac, Mende, Villefort, etc.).\n• **Navette assurée par l'hôte** : Nombreux sont les hôtes qui proposent gracieusement de venir vous chercher à la gare rurale.\n• **Sur place** : Vélos à assistance électrique mis à disposition ou sentiers de randonnée (GR/PR) au départ direct du gîte.`,
    actions: [
      { label: 'Voir la carte des gîtes', actionType: 'navigate', payload: 'map' },
      { label: 'Charte écologique', actionType: 'topic', payload: 'charte_durabilite' }
    ]
  },
  {
    id: 'charte_durabilite',
    title: '🌿 Critères éco-responsables',
    iconName: 'leaf',
    botReply: `Pour figurer sur MyStay, un gîte doit justifier d'au moins 3 engagements vérifiés :\n\n1. **Tri sélectif & compostage autonome**\n2. **Énergie 100% renouvelable / chauffe-eau solaire**\n3. **Gestion sobre de l'eau (récupérateurs de pluie)**\n4. **Panier du terroir & permaculture locale**\n5. **Mobilité douce & prêt de vélos**\n6. **Refuge biodiversité (convention LPO)**`,
    actions: [
      { label: 'Déposer mon gîte engagé', actionType: 'navigate', payload: 'host' }
    ]
  },
  {
    id: 'contact_humain',
    title: '📞 Parler à un conseiller MyStay',
    iconName: 'phone',
    botReply: `Notre équipe humaine est à votre écoute depuis notre antenne rurale en Lozère :\n\n• **Téléphone** : +33 4 66 45 00 12 (du lundi au vendredi, 9h - 18h)\n• **Email support** : contact@mystay-rural.fr\n• **Adresse** : Antenne MyStay Terroirs, 48400 Florac Trois Rivières, Parc National des Cévennes\n• **Messagerie interne** : Échangez en direct avec vos hôtes et le support dans votre espace compte.`,
    actions: [
      { label: 'Ouvrir la messagerie', actionType: 'modal', payload: 'messages' },
      { label: 'Retour au menu d’aide', actionType: 'topic', payload: 'menu' }
    ]
  }
];

export const KumbaBot: React.FC = () => {
  const { 
    setActiveView, 
    openAuthModal, 
    openProfileModal,
    currentUser, 
    isAuthenticated,
    bookings, 
    listings,
    setActiveChatBookingId 
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // User identification helpers
  const isVisitor = !isAuthenticated || !currentUser || currentUser.id === 'usr_guest' || currentUser.name === 'Visiteur';
  const fullName = !isVisitor && currentUser?.name ? currentUser.name.trim() : '';
  const nameParts = fullName ? fullName.split(/\s+/) : [];
  const firstName = nameParts.length > 0 ? nameParts[0] : '';
  const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'voyageur': return 'Voyageur éco-touriste';
      case 'hote': return 'Hôte rural certifié';
      case 'admin': return 'Super Administrateur MyStay';
      case 'moderateur': return 'Médiatrice & Qualité des séjours';
      default: return 'Membre MyStay';
    }
  };

  const getWelcomeText = (user: typeof currentUser, authed: boolean) => {
    const visitor = !authed || !user || user.id === 'usr_guest' || user.name === 'Visiteur';
    if (visitor) {
      return `👋 Bonjour cher voyageur !\n\nJe suis **Koumba**, votre conseillère terroirs et guide MyStay pour le tourisme rural éco-responsable.\n\nVous naviguez actuellement en **mode visiteur**. Pour que je puisse accéder à vos réservations ou à vos gîtes et vous accompagner sur-mesure, vous pouvez vous connecter à tout moment. Comment puis-je vous aider aujourd'hui ?`;
    }
    const fName = user.name ? user.name.trim().split(/\s+/)[0] : '';
    const roleDesc = getRoleLabel(user.role);
    const userTrips = bookings.filter(b => b.travelerId === user.id);
    const tripNote = user.role === 'voyageur' && userTrips.length > 0 
      ? ` J'ai bien accès à vos **${userTrips.length} réservation(s)** en cours.` 
      : '';

    return `👋 Bonjour **${user.name}** ! Ravie de vous retrouver sur MyStay.\n\nJe suis **Koumba**, votre conseillère terroirs et guide d'éco-tourisme rural. Je vois que vous êtes connecté(e) en tant que **${roleDesc}** (${user.email}).${tripNote}\n\nComment puis-je vous être utile aujourd'hui, **${fName || user.name}** ? Choisissez une question ci-dessous ou écrivez-moi directement !`;
  };

  const [messages, setMessages] = useState<BotMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'bot',
      text: getWelcomeText(currentUser, isAuthenticated),
      timestamp: 'À l’instant'
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const previousUserIdRef = useRef<string>(currentUser?.id || '');

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setHasUnread(false);
    }
  }, [isOpen, messages, isTyping]);

  // Dynamically greet when user connection state changes
  useEffect(() => {
    const currentId = currentUser?.id || 'guest';
    if (previousUserIdRef.current !== currentId) {
      previousUserIdRef.current = currentId;
      const newWelcome = getWelcomeText(currentUser, isAuthenticated);
      setMessages(prev => [
        ...prev,
        {
          id: `msg_session_${Date.now()}`,
          sender: 'bot',
          text: !isVisitor 
            ? `✨ **Ravi(e) de vous identifier, ${fullName} !**\nKoumba a synchronisé votre session (${getRoleLabel(currentUser.role)}). Vos séjours et préférences sont reconnus avec exactitude.`
            : `ℹ️ Vous êtes désormais en mode visiteur. Connectez-vous quand vous le souhaitez pour que je vous appelle par votre vrai nom !`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [currentUser?.id, isAuthenticated]);

  const handleSelectTopic = (topicId: string) => {
    if (topicId === 'menu') {
      const address = firstName ? `${firstName}, ` : '';
      triggerBotReply(`Voici l'ensemble des thématiques où je peux vous guider avec précision, ${address}:`, undefined, true);
      return;
    }

    if (topicId === 'qui_suis_je') {
      const userMsg: BotMessage = {
        id: `usr_${Date.now()}`,
        sender: 'user',
        text: '👤 Qui suis-je en ligne ?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, userMsg]);
      setIsTyping(true);

      setTimeout(() => {
        setIsTyping(false);
        let reply = '';
        let actions: BotMessage['quickActions'] = [];

        if (!isVisitor && currentUser) {
          const userTrips = bookings.filter(b => b.travelerId === currentUser.id);
          const userListings = listings.filter(l => l.hostId === currentUser.id);
          const roleDisplay = getRoleLabel(currentUser.role);

          let activity = '';
          if (currentUser.role === 'voyageur') {
            activity = userTrips.length > 0 
              ? `\n• **Vos séjours réservés** : ${userTrips.length} dossier(s) actif(s) (ex: ${userTrips[0].listingTitle})`
              : `\n• **Vos séjours réservés** : Aucun séjour en cours, prêt pour une nouvelle découverte rurale !`;
          } else if (currentUser.role === 'hote') {
            activity = userListings.length > 0
              ? `\n• **Vos gîtes enregistrés** : ${userListings.length} hébergement(s) en gestion`
              : `\n• **Vos hébergements** : Espace hôte prêt pour votre première publication.`;
          }

          reply = `Oui, je sais exactement qui est en ligne avec moi, **${firstName}** !\n\n• **Nom complet** : ${fullName}\n• **Prénom** : ${firstName}${lastName ? `\n• **Nom de famille** : ${lastName}` : ''}\n• **Adresse e-mail** : ${currentUser.email}\n• **Rôle actif** : ${roleDisplay}${activity}\n\nC'est un réel plaisir de vous assister personnellement, **${fullName}** ! Y a-t-il une action ou une question sur votre compte que vous souhaitez réaliser ?`;
          actions = [
            { label: 'Modifier mon profil', actionType: 'modal', payload: 'profile' },
            ...(currentUser.role === 'hote' 
              ? [{ label: 'Espace Hôte', actionType: 'navigate' as const, payload: 'host' }]
              : [{ label: 'Mes séjours & réservations', actionType: 'navigate' as const, payload: 'my_trips' }])
          ];
        } else {
          reply = `Actuellement, vous naviguez en **mode visiteur (non connecté)**.\n\nJe n'ai donc pas encore accès à votre vrai nom ou prénom. Si vous possédez déjà un compte (par exemple **Ba Tamsir** en voyageur ou un compte hôte rural), connectez-vous dès maintenant pour que je puisse vous identifier en direct !`;
          actions = [
            { label: '🔑 Se connecter maintenant', actionType: 'modal' as const, payload: 'auth' },
            { label: 'Explorer les hébergements', actionType: 'navigate' as const, payload: 'explore' }
          ];
        }

        setMessages(prev => [
          ...prev,
          {
            id: `bot_${Date.now()}`,
            sender: 'bot',
            text: reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            topicId: 'qui_suis_je',
            quickActions: actions
          }
        ]);
      }, 450);
      return;
    }

    const topic = PREDEFINED_TOPICS.find(t => t.id === topicId);
    if (!topic) return;

    // Add user question message
    const userMsg: BotMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: topic.title,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    // Personalize reply with user name
    setTimeout(() => {
      let personalizedReply = topic.botReply;
      if (!isVisitor && firstName) {
        if (topic.id === 'deposer_annonce') {
          personalizedReply = `Avec plaisir **${firstName}** ! Pour inscrire votre hébergement ou celui de votre entourage sur MyStay, voici la marche à suivre :\n\n1. **Commune rurale** : Votre gîte doit se situer dans une commune rurale préservée.\n2. **Charte Éco-responsable** : Au moins 3 critères durables (énergie, eau, circuits courts).\n3. **Photos & Vidéos** : Vous pouvez désormais insérer une **vidéo immersive** (YouTube ou MP4) pour valoriser votre terroir !\n4. **Rémunération** : 88% du montant net vous est directement reversé.`;
        } else if (topic.id === 'reservation_paiement') {
          personalizedReply = `Absolument, **${firstName}** ! Voici comment se déroule la réservation sécurisée pour vos séjours :\n\n• **Paiement Stripe 100% sécurisé** : Chiffrement SSL/TLS, aucun numéro de carte conservé.\n• **Confirmation immédiate** ou sous 24h selon le choix de l'hôte.\n• **Votre impact** : Chaque nuitée calcule précisément les kg de CO₂ économisés face aux hébergements classiques.`;
        } else if (topic.id === 'photo_profil') {
          personalizedReply = `Très bonne question, **${fullName}** !\n\n• Vous pouvez modifier votre photo ou votre avatar à tout moment depuis votre profil.\n• Vos données personnelles sont hébergées en Europe en conformité intégrale avec le RGPD.\n• N'hésitez pas à vérifier votre profil en 1 clic.`;
        }
      }

      const botMsg: BotMessage = {
        id: `bot_${Date.now()}`,
        sender: 'bot',
        text: personalizedReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        topicId: topic.id,
        quickActions: topic.actions
      };
      setIsTyping(false);
      setMessages(prev => [...prev, botMsg]);
    }, 450);
  };

  const triggerBotReply = (text: string, actions?: BotMessage['quickActions'], isReturnMenu = false) => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const botMsg: BotMessage = {
        id: `bot_${Date.now()}`,
        sender: 'bot',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        quickActions: actions
      };
      setMessages(prev => [...prev, botMsg]);
    }, 400);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = inputText.trim();
    if (!query) return;

    const userMsg: BotMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    const q = (query || '').toLowerCase();

    setTimeout(() => {
      setIsTyping(false);

      // Check if user is asking who they are or who is online
      const isAskingWhoAmI = (
        q.includes('qui suis') || 
        q.includes('qui est en ligne') || 
        q.includes('tu sais qui') || 
        q.includes('tu me connais') || 
        q.includes('mon nom') || 
        q.includes('mon prénom') || 
        q.includes('mon prenom') || 
        q.includes('mon profil') || 
        q.includes('mon compte') || 
        q.includes('qui est connecté') || 
        q.includes('qui est connecte') || 
        q.includes('comment je m appelle') || 
        q.includes('comment je m’appelle') ||
        q.includes('tu me reconnais') ||
        q.includes('est-ce que tu me reconnais')
      );

      if (isAskingWhoAmI) {
        if (!isVisitor && currentUser) {
          const userTrips = bookings.filter(b => b.travelerId === currentUser.id);
          const userListings = listings.filter(l => l.hostId === currentUser.id);
          const roleDisplay = getRoleLabel(currentUser.role);

          let extraInfo = '';
          if (currentUser.role === 'voyageur') {
            extraInfo = userTrips.length > 0 
              ? `\n• **Historique séjours** : ${userTrips.length} réservation(s) rattachée(s) à votre compte.`
              : `\n• **Historique séjours** : Aucune réservation active pour le moment.`;
          } else if (currentUser.role === 'hote') {
            extraInfo = `\n• **Gîtes gérés** : ${userListings.length} hébergement(s) ruraux répertorié(s).`;
          }

          setMessages(prev => [
            ...prev,
            {
              id: `bot_${Date.now()}`,
              sender: 'bot',
              text: `Oui, je sais exactement qui est en ligne avec moi, **${firstName}** !\n\n• **Nom complet** : ${fullName}\n• **Prénom** : ${firstName}${lastName ? `\n• **Nom de famille** : ${lastName}` : ''}\n• **Adresse e-mail** : ${currentUser.email}\n• **Statut de votre compte** : ${roleDisplay}${extraInfo}\n\nJe suis très heureuse de dialoguer directement avec vous, **${fullName}**. Que souhaitez-vous savoir ou organiser aujourd'hui ?`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              quickActions: [
                { label: 'Gérer mon profil', actionType: 'modal', payload: 'profile' },
                { label: 'Mes séjours', actionType: 'navigate', payload: 'my_trips' }
              ]
            }
          ]);
          return;
        } else {
          setMessages(prev => [
            ...prev,
            {
              id: `bot_${Date.now()}`,
              sender: 'bot',
              text: `Actuellement, vous naviguez en **mode visiteur (non connecté)**.\n\nJe ne connais donc pas encore votre nom ou votre prénom. Si vous avez un compte MyStay (comme **Ba Tamsir** en voyageur ou un compte hôte), connectez-vous afin que je puisse vous identifier immédiatement et vous appeler par votre nom !`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              quickActions: [
                { label: '🔑 Se connecter maintenant', actionType: 'modal', payload: 'auth' },
                { label: 'Explorer les gîtes', actionType: 'navigate', payload: 'explore' }
              ]
            }
          ]);
          return;
        }
      }

      // Keyword matching with personalized tone
      const politeAddress = !isVisitor && firstName ? `${firstName}, ` : '';

      let matchedTopic: PredefinedTopic | undefined;

      if (q.includes('vidéo') || q.includes('video') || q.includes('film') || q.includes('mp4') || q.includes('youtube') || q.includes('vimeo')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'video_annonce');
      } else if (q.includes('photo') || q.includes('avatar') || q.includes('profil') || q.includes('image') || q.includes('ba tamsir') || q.includes('inscription') || q.includes('compte')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'photo_profil');
      } else if (q.includes('rgpd') || q.includes('donnée') || q.includes('donnee') || q.includes('privacy') || q.includes('loi') || q.includes('europe') || q.includes('cnil') || q.includes('securit') || q.includes('sécurit')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'rgpd_protection');
      } else if (q.includes('déposer') || q.includes('deposer') || q.includes('annonce') || q.includes('hôte') || q.includes('hote') || q.includes('commune') || q.includes('region') || q.includes('région') || q.includes('publier')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'deposer_annonce');
      } else if (q.includes('réserver') || q.includes('reserver') || q.includes('paiement') || q.includes('carte') || q.includes('stripe') || q.includes('prix') || q.includes('co2')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'reservation_paiement');
      } else if (q.includes('train') || q.includes('gare') || q.includes('vélo') || q.includes('velo') || q.includes('navette') || q.includes('transport') || q.includes('mobilit')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'mobilite_douce');
      } else if (q.includes('charte') || q.includes('ecolo') || q.includes('écolo') || q.includes('critere') || q.includes('critère') || q.includes('durab') || q.includes('label')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'charte_durabilite');
      } else if (q.includes('contact') || q.includes('telephone') || q.includes('téléphone') || q.includes('humain') || q.includes('aide') || q.includes('parler') || q.includes('equipe') || q.includes('équipe')) {
        matchedTopic = PREDEFINED_TOPICS.find(t => t.id === 'contact_humain');
      }

      if (matchedTopic) {
        setMessages(prev => [
          ...prev,
          {
            id: `bot_${Date.now()}`,
            sender: 'bot',
            text: `${politeAddress ? `Bien sûr **${firstName}** ! ` : ''}${matchedTopic!.botReply}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            topicId: matchedTopic!.id,
            quickActions: matchedTopic!.actions
          }
        ]);
      } else {
        setMessages(prev => [
          ...prev,
          {
            id: `bot_${Date.now()}`,
            sender: 'bot',
            text: `${politeAddress ? `Je vous réponds avec attention **${firstName}** : ` : ''}concernant votre demande « ${query} », voici les rubriques où je peux vous guider directement :`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            quickActions: [
              { label: '👤 Qui suis-je en ligne ?', actionType: 'topic', payload: 'qui_suis_je' },
              { label: '🏡 Déposer une annonce', actionType: 'topic', payload: 'deposer_annonce' },
              { label: '💳 Réservation & Paiement', actionType: 'topic', payload: 'reservation_paiement' },
              { label: '🎥 Ajouter une vidéo', actionType: 'topic', payload: 'video_annonce' },
              { label: '🛡️ Données & RGPD', actionType: 'topic', payload: 'rgpd_protection' },
              { label: '📞 Joindre l’équipe', actionType: 'topic', payload: 'contact_humain' }
            ]
          }
        ]);
      }
    }, 450);
  };

  const handleActionClick = (action: { label: string; actionType: string; payload?: string }) => {
    if (action.actionType === 'topic' && action.payload) {
      handleSelectTopic(action.payload);
    } else if (action.actionType === 'navigate' && action.payload) {
      setActiveView(action.payload as any);
      setIsOpen(false);
    } else if (action.actionType === 'modal') {
      if (action.payload === 'auth') {
        openAuthModal('signup');
        setIsOpen(false);
      } else if (action.payload === 'profile') {
        openProfileModal();
        setIsOpen(false);
      } else if (action.payload === 'messages') {
        if (bookings && bookings.length > 0) {
          setActiveChatBookingId(bookings[0].id);
        } else {
          setActiveView('my_trips');
        }
        setIsOpen(false);
      } else if (action.payload === 'rgpd') {
        const footer = document.querySelector('footer');
        if (footer) {
          footer.scrollIntoView({ behavior: 'smooth' });
        }
        setIsOpen(false);
      }
    }
  };

  const resetChat = () => {
    setMessages([
      {
        id: `msg_${Date.now()}`,
        sender: 'bot',
        text: `Conversation réinitialisée. Bonjour, je suis **Koumba** ! Comment puis-je vous accompagner aujourd'hui sur MyStay${!isVisitor && firstName ? `, ${firstName}` : ''} ?`,
        timestamp: 'À l’instant'
      }
    ]);
  };

  return (
    <>
      {/* Floating Launcher Button with Koumba's warm welcoming African Avatar */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {!isOpen && (
          <div 
            onClick={() => setIsOpen(true)}
            className="mb-3 hidden sm:flex items-center gap-3 bg-stone-900/95 text-white pl-2 pr-3.5 py-1.5 rounded-full shadow-2xl border border-stone-700 hover:border-emerald-500/60 transition cursor-pointer group animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            <div className="relative">
              <img
                src={KOUMBA_AVATAR}
                alt="Koumba"
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover ring-2 ring-emerald-400 group-hover:scale-105 transition"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-stone-900 rounded-full animate-pulse" />
            </div>
            <div className="flex flex-col text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white">Koumba</span>
                <span className="text-[10px] text-emerald-300 bg-emerald-950/70 border border-emerald-500/30 px-1.5 py-0.2 rounded-full font-medium">
                  En ligne
                </span>
              </div>
              <span className="text-[11px] text-stone-300">
                {!isVisitor ? `À l’écoute de ${firstName || fullName}` : 'Une question sur vos séjours ?'}
              </span>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setHasUnread(false);
              }}
              className="text-stone-400 hover:text-stone-200 ml-1 p-1 hover:bg-stone-800 rounded-full cursor-pointer"
              title="Masquer l’alerte"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <button
          id="btn-open-kumbabot"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="relative w-13 h-13 sm:w-14 sm:h-14 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer overflow-hidden border-2 border-[#A3E5C8] group bg-[#243E36]"
          title="Discuter avec Koumba (Conseillère terroirs MyStay)"
        >
          {isOpen ? (
            <div className="w-full h-full flex items-center justify-center bg-[#243E36] text-white">
              <X className="w-6 h-6" />
            </div>
          ) : (
            <div className="relative w-full h-full">
              <img
                src={KOUMBA_AVATAR}
                alt="Koumba"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <span className="absolute bottom-1 right-1 w-3.5 h-3.5 bg-emerald-400 border-2 border-white rounded-full shadow-xs" />
            </div>
          )}

          {hasUnread && !isOpen && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full border-2 border-white flex items-center justify-center text-[9px] font-bold text-black animate-bounce shadow-md">
              1
            </span>
          )}
        </button>
      </div>

      {/* Chat Window Panel */}
      {isOpen && (
        <div 
          id="kumba-chat-window"
          className="fixed bottom-20 sm:bottom-24 right-2 sm:right-6 left-2 sm:left-auto w-[calc(100vw-1rem)] sm:w-[410px] max-w-md h-[550px] max-h-[82vh] bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-stone-200 flex flex-col z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        >
          {/* Header with Koumba's Avatar & Role */}
          <div className="bg-gradient-to-r from-[#243E36] via-[#2c4e44] to-[#1e342d] text-white p-3.5 sm:p-4 flex items-center justify-between shrink-0 shadow-sm">
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="relative shrink-0">
                <img
                  src={KOUMBA_AVATAR}
                  alt="Koumba"
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-[#A3E5C8] shadow-md"
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-[#243E36] rounded-full" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="font-bold text-base tracking-tight text-white">Koumba</h3>
                  <span className="text-[10px] bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-emerald-300" />
                    Guide Terroirs
                  </span>
                </div>
                <p className="text-[11px] text-emerald-100/90 leading-tight truncate">
                  {!isVisitor ? `À l’écoute de ${firstName || fullName}` : 'Accueil & Conseils éco-tourisme'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={resetChat}
                className="p-1.5 rounded-lg hover:bg-white/15 text-emerald-100 transition cursor-pointer"
                title="Recommencer la discussion"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/15 text-emerald-100 transition cursor-pointer"
                title="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Connected User Identification Bar */}
          <div className="bg-gradient-to-r from-emerald-50 via-stone-50 to-emerald-50/60 border-b border-emerald-100 px-3.5 py-2 flex items-center justify-between text-xs">
            {!isVisitor && currentUser ? (
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="relative shrink-0">
                    {currentUser.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover ring-1 ring-emerald-600 shadow-2xs"
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-emerald-800 text-white text-[10px] font-bold flex items-center justify-center">
                        {firstName ? firstName[0] : 'U'}
                      </div>
                    )}
                    <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full border border-white" />
                  </div>
                  <div className="truncate text-[11px]">
                    <span className="text-stone-500">En ligne : </span>
                    <strong className="text-emerald-950 font-bold">{fullName}</strong>
                    <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-md bg-emerald-200/70 text-emerald-900 font-medium">
                      {currentUser.role === 'hote' ? 'Hôte' : currentUser.role === 'voyageur' ? 'Voyageur' : 'Admin'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => openProfileModal()}
                  className="text-[10px] font-semibold text-emerald-800 hover:text-emerald-950 underline shrink-0 ml-2 cursor-pointer"
                >
                  Mon profil
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between w-full">
                <span className="flex items-center gap-1.5 text-stone-600 text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-stone-400" />
                  <span>Mode <strong>Visiteur</strong></span>
                </span>
                <button
                  type="button"
                  onClick={() => openAuthModal('login')}
                  className="text-[10px] font-bold text-emerald-800 bg-white hover:bg-emerald-100 px-2 py-0.5 rounded-lg border border-emerald-300 shadow-2xs transition cursor-pointer"
                >
                  Se connecter
                </button>
              </div>
            )}
          </div>

          {/* Sub-banner: RGPD & European Protection */}
          <div className="bg-stone-50 border-b border-stone-200 px-3.5 py-1 flex items-center justify-between text-[11px] text-stone-600">
            <span className="flex items-center gap-1 font-medium text-[10px]">
              <Shield className="w-3 h-3 text-emerald-700 shrink-0" />
              <span>Conforme RGPD • Données confidentielles UE</span>
            </span>
            <button
              type="button"
              onClick={() => handleSelectTopic('rgpd_protection')}
              className="text-[10px] underline hover:text-stone-900 cursor-pointer font-semibold text-emerald-800"
            >
              En savoir plus
            </button>
          </div>

          {/* Messages Flow */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-stone-50/40">
            {messages.map((msg) => (
              <div 
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-1.5`}
              >
                {msg.sender === 'bot' ? (
                  <div className="flex items-start gap-2.5 max-w-[90%]">
                    <img
                      src={KOUMBA_AVATAR}
                      alt="Koumba"
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-full object-cover ring-1 ring-emerald-500/60 shrink-0 mt-0.5 shadow-2xs"
                    />
                    <div className="flex flex-col items-start space-y-1">
                      <div className="bg-white text-stone-800 border border-stone-200/90 rounded-2xl rounded-tl-xs px-3.5 py-2.5 text-xs leading-relaxed shadow-xs whitespace-pre-line">
                        {msg.text}
                      </div>

                      {/* Quick Action buttons associated with bot reply */}
                      {msg.quickActions && msg.quickActions.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {msg.quickActions.map((act, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleActionClick(act)}
                              className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 transition cursor-pointer shadow-2xs"
                            >
                              <span>{act.label}</span>
                              <ChevronRight className="w-3 h-3 text-emerald-700" />
                            </button>
                          ))}
                        </div>
                      )}

                      <span className="text-[10px] text-stone-400 px-1">
                        Koumba • {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-end gap-2 max-w-[88%] ml-auto">
                    <div className="flex flex-col items-end space-y-1">
                      <div className="bg-[#243E36] text-white rounded-2xl rounded-tr-xs px-3.5 py-2.5 text-xs leading-relaxed shadow-xs whitespace-pre-line">
                        {msg.text}
                      </div>
                      <span className="text-[10px] text-stone-400 px-1">{msg.timestamp}</span>
                    </div>
                    {currentUser?.avatar && !isVisitor ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        referrerPolicy="no-referrer"
                        className="w-7 h-7 rounded-full object-cover ring-1 ring-emerald-700 shrink-0 mt-0.5 shadow-2xs"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-[#1b312a] text-white text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                        {firstName ? firstName[0] : 'V'}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-2 max-w-[85%]">
                <img
                  src={KOUMBA_AVATAR}
                  alt="Koumba"
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover ring-1 ring-emerald-500/60 shrink-0"
                />
                <div className="flex items-center gap-1.5 text-stone-500 bg-white border border-stone-200 px-3 py-2 rounded-2xl shadow-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 animate-bounce [animation-delay:0.4s]" />
                  <span className="text-[11px] text-stone-600 ml-1 font-medium">
                    Koumba vous répond...
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Choice Buttons Carousel */}
          <div className="p-2.5 bg-white border-t border-stone-200 space-y-2">
            <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider px-1 flex items-center justify-between">
              <span>Thèmes fréquents :</span>
              <span className="text-emerald-800 font-semibold">1 clic</span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
              {PREDEFINED_TOPICS.map((topic) => (
                <button
                  key={topic.id}
                  type="button"
                  onClick={() => handleSelectTopic(topic.id)}
                  className={`shrink-0 text-left text-[11px] font-medium px-2.5 py-1.5 rounded-xl border transition cursor-pointer shadow-2xs ${
                    topic.id === 'qui_suis_je'
                      ? 'border-emerald-400 bg-emerald-50/80 text-emerald-950 font-bold hover:bg-emerald-100'
                      : 'border-stone-200 bg-stone-50 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-950'
                  }`}
                >
                  {topic.title}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="flex items-center gap-1.5 pt-1">
              <input
                id="kumbabot-input-query"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={!isVisitor && firstName ? `Posez votre question, ${firstName}...` : "Posez votre question à Koumba..."}
                className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 transition"
              />
              <button
                id="btn-send-kumbabot"
                type="submit"
                disabled={!inputText.trim()}
                className="p-2.5 bg-[#243E36] hover:bg-[#1a2e28] disabled:opacity-40 text-white rounded-xl transition cursor-pointer shadow-xs shrink-0"
                title="Envoyer votre message"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
