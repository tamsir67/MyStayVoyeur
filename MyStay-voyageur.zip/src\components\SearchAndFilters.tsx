import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search, MapPin, Calendar, Users, SlidersHorizontal,
  RotateCcw, Award, Leaf, Shield, HeartHandshake, Trees,
  X, Plus, Minus, ArrowRight
} from 'lucide-react';
import { MyStayLabel } from '../types';

export const SearchAndFilters: React.FC = () => {
  const { filters, setFilters, resetFilters } = useApp();
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Airbnb Search Popup State
  const [isAirbnbModalOpen, setIsAirbnbModalOpen] = useState(false);
  const [modalDestinationInput, setModalDestinationInput] = useState(filters.searchQuery || '');
  const [modalRegion, setModalRegion] = useState(filters.region || 'all');
  const [modalStartDate, setModalStartDate] = useState(filters.startDate || '');
  const [modalEndDate, setModalEndDate] = useState(filters.endDate || '');
  const [modalGuests, setModalGuests] = useState(filters.guests || 2);
  const [isDestinationDropdownOpen, setIsDestinationDropdownOpen] = useState(false);

  const POPULAR_DESTINATIONS = [
    { name: 'Toutes les destinations', region: 'all', desc: 'Partout en France rurale' },
    { name: 'Monts d’Arrée & Forêt d’Huelgoat', region: 'Bretagne', desc: 'Chaumières en granit & landes légendaires' },
    { name: 'Pays d’Auge & Suisse Normande', region: 'Normandie', desc: 'Pressoirs à pans de bois & vergers à cidre' },
    { name: 'Volcans d’Auvergne & Cantal', region: 'Auvergne-Rhône-Alpes', desc: 'Burons d’altitude & monts préservés' },
    { name: 'Ballons des Vosges & Hautes-Chaumes', region: 'Grand Est', desc: 'Chalets en fuste & forêts de sapins' },
    { name: 'Périgord Noir & Vallée de la Dordogne', region: 'Nouvelle-Aquitaine', desc: 'Pigeonniers ocres, chênaies & canoë' },
    { name: 'Plateau de Millevaches & Creuse', region: 'Nouvelle-Aquitaine', desc: 'Tourbières sauvages & ciel étoilé pur' },
    { name: 'Cévennes & Parc National', region: 'Occitanie', desc: 'Moulins de schiste & vallons préservés' },
    { name: 'Causses du Larzac & Gorges du Tarn', region: 'Occitanie', desc: 'Jasses templières & agritourisme Roquefort' },
    { name: 'Morvan & Terres d’Eau', region: 'Bourgogne-Franche-Comté', desc: 'Éco-cabanes, forêts denses & lacs purs' },
    { name: 'Luberon & Pays d’Apt', region: "Provence-Alpes-Côte d'Azur", desc: 'Bergeries en pierre sèche, oliviers & ocres' },
    { name: 'Pays Basque & Pyrénées', region: 'Nouvelle-Aquitaine', desc: 'Fermes vivrières & estives montagnardes' },
    { name: 'Drôme des Collines & Vercors', region: 'Auvergne-Rhône-Alpes', desc: 'Yourtes bio, lavande & poteries artisanales' },
    { name: 'Sologne des Étangs & Forêts', region: 'Centre-Val de Loire', desc: 'Pavillons de brique & refuges ornithologiques LPO' },
    { name: 'Castagniccia & Moyenne Montagne', region: 'Corse', desc: 'Caseddi en pierre & châtaigneraies centenaires' },
    { name: 'Baie de Somme & Bocage Picard', region: 'Hauts-de-France', desc: 'Longères en torchis & pré-salés préservés' }
  ];

  const calculateNights = (start: string, end: string) => {
    if (!start || !end) return 0;
    const s = new Date(start).getTime();
    const e = new Date(end).getTime();
    if (isNaN(s) || isNaN(e) || e <= s) return 0;
    return Math.round((e - s) / (1000 * 60 * 60 * 24));
  };

  const filteredDestinations = POPULAR_DESTINATIONS.filter(d => {
    if (!modalDestinationInput) return true;
    const q = modalDestinationInput.toLowerCase();
    return d.name.toLowerCase().includes(q) || d.desc.toLowerCase().includes(q) || d.region.toLowerCase().includes(q);
  });

  const regions = [
    { value: 'all', label: 'Toutes les régions rurales de France' },
    { value: 'Bretagne', label: 'Bretagne (Monts d’Arrée, Trégor)' },
    { value: 'Normandie', label: 'Normandie (Pays d’Auge, Suisse Normande)' },
    { value: 'Auvergne-Rhône-Alpes', label: 'Auvergne & Cantal, Drôme' },
    { value: 'Grand Est', label: 'Grand Est (Ballons des Vosges)' },
    { value: 'Nouvelle-Aquitaine', label: 'Nouvelle-Aquitaine (Périgord, Creuse, Pays Basque)' },
    { value: 'Occitanie', label: 'Occitanie (Cévennes, Lozère, Larzac)' },
    { value: 'Bourgogne-Franche-Comté', label: 'Bourgogne (Morvan & Terres d’eau)' },
    { value: "Provence-Alpes-Côte d'Azur", label: 'PACA (Luberon, Haute-Provence)' },
    { value: 'Centre-Val de Loire', label: 'Centre-Val de Loire (Sologne des Étangs)' },
    { value: 'Corse', label: 'Corse (Castagniccia & Terroirs)' },
    { value: 'Hauts-de-France', label: 'Hauts-de-France (Baie de Somme)' }
  ];

  const propertyTypes = [
    { value: 'all', label: 'Tous types d’habitats ruraux' },
    { value: 'moulin', label: 'Moulins à eau & farine' },
    { value: 'eco_cabane', label: 'Éco-Cabanes en bois' },
    { value: 'longere', label: 'Longères & chaumières traditionnelles' },
    { value: 'buron', label: 'Burons d’estive volcaniques' },
    { value: 'chalet_fuste', label: 'Fustes & chalets d’altitude' },
    { value: 'pressoir', label: 'Pressoirs & colombages' },
    { value: 'pigeonnier', label: 'Pigeonniers périgourdins' },
    { value: 'bergerie', label: 'Bergeries & jasses en pierre sèche' },
    { value: 'ferme_renovee', label: 'Fermes vivrières & métairies' },
    { value: 'yourte', label: 'Yourtes & habitats légers' }
  ];

  const labelsConfig: { id: MyStayLabel; label: string; icon: React.ReactNode; color: string; desc: string }[] = [
    { 
      id: 'eco_responsable', 
      label: 'Éco-responsable', 
      icon: <Leaf className="w-3.5 h-3.5" />, 
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300',
      desc: 'Pratiques environnementales documentées et vérifiées' 
    },
    { 
      id: 'authentique', 
      label: 'Authentique', 
      icon: <Trees className="w-3.5 h-3.5" />, 
      color: 'bg-amber-50 text-amber-800 border-amber-300',
      desc: 'Hébergement représentatif du patrimoine local' 
    },
    { 
      id: 'accueil_engage', 
      label: 'Accueil engagé', 
      icon: <HeartHandshake className="w-3.5 h-3.5" />, 
      color: 'bg-orange-50 text-orange-800 border-orange-300',
      desc: 'Hôte favorisant échanges, conseils et circuit court' 
    },
    { 
      id: 'rural_prioritaire', 
      label: 'Rural prioritaire', 
      icon: <Shield className="w-3.5 h-3.5" />, 
      color: 'bg-stone-100 text-stone-800 border-stone-300',
      desc: 'Territoire rural sous-exploité à revitaliser' 
    }
  ];

  const toggleLabel = (labelId: MyStayLabel) => {
    setFilters(prev => {
      const currentLabels = prev.labels || [];
      const exists = currentLabels.includes(labelId);
      return {
        ...prev,
        labels: exists ? currentLabels.filter(l => l !== labelId) : [...currentLabels, labelId]
      };
    });
  };

  return (
    <div className="bg-[#FAF9F5] border-b border-[#E6E4DD] py-5 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-4">
        
        {/* Main Search Bar (5-step simple search) */}
        <div className="bg-white rounded-2xl p-2.5 shadow-sm border border-[#DEDBD2] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-2 items-center">
          
          {/* Destination */}
          <div className="lg:col-span-4 flex items-center gap-3 px-3 py-1.5 border-b lg:border-b-0 md:border-r border-stone-200 min-w-0">
            <div className="p-2 bg-[#F3F1E9] rounded-xl text-[#243E36]">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <label className="block text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                Destination rurale
              </label>
              <select
                id="search-region-select"
                value={filters.region}
                onChange={e => setFilters(prev => ({ ...prev, region: e.target.value }))}
                className="w-full text-xs font-semibold text-stone-900 bg-transparent outline-none truncate cursor-pointer"
              >
                {regions.map(r => (
                  <option key={r.value} value={r.value}>{r.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Dates */}
          <div className="lg:col-span-4 flex items-center gap-3 px-3 py-1.5 border-b lg:border-b-0 lg:border-r border-stone-200 min-w-0">
            <div className="p-2 bg-[#F3F1E9] rounded-xl text-[#243E36]">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="flex-1 grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                  Arrivée
                </label>
                <input
                  id="search-start-date"
                  type="date"
                  value={filters.startDate}
                  onChange={e => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                  className="w-full text-xs text-stone-900 bg-transparent outline-none cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                  Départ
                </label>
                <input
                  id="search-end-date"
                  type="date"
                  value={filters.endDate}
                  onChange={e => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                  className="w-full text-xs text-stone-900 bg-transparent outline-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Guests & Actions */}
          <div className="md:col-span-2 lg:col-span-4 flex flex-col sm:flex-row sm:items-center gap-2.5 sm:gap-3 px-3 py-1.5 justify-between min-w-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-[#F3F1E9] rounded-xl text-[#243E36] shrink-0">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                  Voyageurs
                </label>
                <select
                  id="search-guests-select"
                  value={filters.guests}
                  onChange={e => setFilters(prev => ({ ...prev, guests: Number(e.target.value) }))}
                  className="text-xs font-semibold text-stone-900 bg-transparent outline-none cursor-pointer"
                >
                  <option value={1}>1 voyageur</option>
                  <option value={2}>2 voyageurs</option>
                  <option value={3}>3 voyageurs</option>
                  <option value={4}>4 voyageurs</option>
                  <option value={5}>5 voyageurs et +</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                id="search-toggle-filters-btn"
                onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center gap-1.5 text-xs font-medium shrink-0 ${
                  showAdvancedFilters || (filters.labels?.length || 0) > 0 || filters.propertyType !== 'all' || (filters.maxPrice !== undefined && filters.maxPrice < 250)
                    ? 'bg-[#243E36] text-white border-[#243E36]'
                    : 'bg-[#F7F6F0] text-stone-700 border-stone-200 hover:bg-[#EAE8DE]'
                }`}
                title="Filtres avancés & Labels MyStay"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span className="hidden sm:inline">Filtres</span>
                {(filters.labels?.length || 0) > 0 && (
                  <span className="w-4 h-4 bg-[#A3E5C8] text-[#142923] rounded-full text-[10px] font-bold flex items-center justify-center">
                    {filters.labels?.length}
                  </span>
                )}
              </button>

              {/* Bouton Rechercher inspiré d'Airbnb */}
              <button
                id="search-airbnb-modal-launcher-btn"
                onClick={() => {
                  setModalDestinationInput(filters.searchQuery || (filters.region && filters.region !== 'all' ? filters.region : ''));
                  setModalRegion(filters.region || 'all');
                  setModalStartDate(filters.startDate || '');
                  setModalEndDate(filters.endDate || '');
                  setModalGuests(filters.guests || 2);
                  setIsAirbnbModalOpen(true);
                }}
                className="flex-1 sm:flex-initial px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#243E36] to-[#172d25] hover:from-[#1b302a] hover:to-[#0f1d18] active:scale-95 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md border border-[#A3E5C8]/30 group shrink-0"
                title="Rechercher par destination, dates et voyageurs (Popup Airbnb)"
              >
                <div className="w-4 h-4 rounded-full bg-[#A3E5C8] text-[#142923] flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Search className="w-2.5 h-2.5 stroke-[3]" />
                </div>
                <span className="tracking-wide">Rechercher</span>
              </button>
            </div>

          </div>

        </div>

        {/* Labels Quick Pills (Scrollable smoothly on mobile) */}
        <div className="flex items-center justify-between gap-2 pt-1 overflow-x-auto sm:flex-wrap no-scrollbar">
          <div className="flex items-center gap-1.5 sm:gap-2 flex-nowrap sm:flex-wrap shrink-0">
            <span className="text-xs font-semibold text-stone-500 flex items-center gap-1 shrink-0">
              <Award className="w-3.5 h-3.5 text-[#8C5E45]" /> Labels :
            </span>
            {labelsConfig.map(l => {
              const isSelected = (filters.labels || []).includes(l.id);
              return (
                <button
                  key={l.id}
                  id={`filter-label-${l.id}`}
                  onClick={() => toggleLabel(l.id)}
                  className={`text-xs px-2.5 py-1 rounded-full border transition cursor-pointer flex items-center gap-1.5 font-medium whitespace-nowrap shrink-0 ${
                    isSelected
                      ? `${l.color} shadow-xs ring-1 ring-[#243E36]`
                      : 'bg-white text-stone-600 border-stone-200 hover:bg-stone-50'
                  }`}
                  title={l.desc}
                >
                  {l.icon}
                  <span>{l.label}</span>
                </button>
              );
            })}
          </div>

          {/* Reset Filters button if any filter is active */}
          {(filters.region !== 'all' || filters.propertyType !== 'all' || (filters.labels?.length || 0) > 0 || (filters.maxPrice !== undefined && filters.maxPrice < 250) || filters.startDate) && (
            <button
              id="search-reset-filters-btn"
              onClick={resetFilters}
              className="text-xs text-stone-500 hover:text-stone-900 underline flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0 ml-auto"
            >
              <RotateCcw className="w-3 h-3" />
              Réinitialiser
            </button>
          )}
        </div>

        {/* Advanced Filters Panel */}
        {showAdvancedFilters && (
          <div className="bg-white rounded-2xl p-5 border border-[#DEDBD2] shadow-xs space-y-4 transition-all">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Type de logement */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                  Typologie d’habitat rural
                </label>
                <div className="space-y-1.5">
                  {propertyTypes.map(pt => (
                    <label 
                      key={pt.value} 
                      className="flex items-center gap-2 text-xs text-stone-700 hover:text-stone-900 cursor-pointer"
                    >
                      <input
                        type="radio"
                        name="propertyType"
                        value={pt.value}
                        checked={filters.propertyType === pt.value}
                        onChange={() => setFilters(prev => ({ ...prev, propertyType: pt.value }))}
                        className="text-[#243E36] focus:ring-[#243E36]"
                      />
                      <span>{pt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Prix maximum */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-stone-700 uppercase tracking-wider">
                    Budget max / nuit
                  </label>
                  <span className="text-sm font-bold text-[#243E36]">
                    {filters.maxPrice} €
                  </span>
                </div>
                <input
                  id="filter-max-price-slider"
                  type="range"
                  min={50}
                  max={250}
                  step={5}
                  value={filters.maxPrice}
                  onChange={e => setFilters(prev => ({ ...prev, maxPrice: Number(e.target.value) }))}
                  className="w-full accent-[#243E36] cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-stone-400 mt-1">
                  <span>50 € (authentique sobre)</span>
                  <span>250 € (grand mas)</span>
                </div>
              </div>

              {/* Tri & Critère Écologique strict */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                    Trier les résultats
                  </label>
                  <select
                    id="filter-sort-by-select"
                    value={filters.sortBy}
                    onChange={e => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
                    className="w-full p-2 border border-stone-200 rounded-xl text-xs bg-white text-stone-900 cursor-pointer"
                  >
                    <option value="pertinence">Pertinence & Impact durable</option>
                    <option value="price_asc">Prix le plus bas en premier</option>
                    <option value="price_desc">Prix le plus élevé en premier</option>
                    <option value="rating">Mieux notés par les voyageurs</option>
                  </select>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 text-xs font-medium text-[#243E36] cursor-pointer bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-200">
                    <input
                      type="checkbox"
                      checked={filters.selectedSustainableOnly}
                      onChange={e => setFilters(prev => ({ ...prev, selectedSustainableOnly: e.target.checked }))}
                      className="rounded text-emerald-700 focus:ring-emerald-700"
                    />
                    <span>Exiger ≥ 4 engagements durables validés</span>
                  </label>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>

      {/* Modal Popup Recherche Avancée (Inspiré Airbnb) */}
      {isAirbnbModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex justify-center items-start pt-4 sm:pt-16 pb-8 px-2 sm:px-4 md:px-6 animate-in fade-in duration-200">
          <div 
            id="airbnb-search-popup"
            className="bg-white w-full max-w-2xl rounded-2xl sm:rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col mb-auto animate-in zoom-in-95 duration-200"
          >
            {/* Header */}
            <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-stone-200 flex items-center justify-between bg-[#FAF9F5] sticky top-0 z-10">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#243E36] text-[#A3E5C8] flex items-center justify-center shadow-xs shrink-0">
                  <Search className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-sm sm:text-base text-stone-900 leading-tight">
                    Où souhaitez-vous séjourner ?
                  </h3>
                  <p className="text-[10px] sm:text-[11px] text-stone-500">
                    Recherche par destination, dates et voyageurs
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAirbnbModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400 hover:text-stone-700 transition cursor-pointer"
                title="Fermer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 sm:p-6 space-y-4 sm:space-y-5 overflow-y-auto max-h-[75vh]">
              {/* 1. Destination / Adresse */}
              <div className="space-y-2 relative">
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#8C5E45]" />
                    <span>Adresse de destination ou région</span>
                  </span>
                  <span className="text-[10px] text-stone-400 font-normal">Saisissez ou choisissez ci-dessous</span>
                </label>

                <div className="relative">
                  <input
                    id="modal-destination-input"
                    type="text"
                    value={modalDestinationInput}
                    onChange={e => {
                      setModalDestinationInput(e.target.value);
                      setIsDestinationDropdownOpen(true);
                    }}
                    onFocus={() => setIsDestinationDropdownOpen(true)}
                    placeholder="Ex: Cévennes, Lozère, Morvan, Luberon, Pays Basque, Drôme..."
                    className="w-full text-xs font-semibold text-stone-900 p-3.5 pl-10 pr-10 rounded-2xl border border-stone-300 focus:border-[#243E36] focus:ring-2 focus:ring-[#243E36]/20 outline-none bg-stone-50/60 shadow-xs transition"
                  />
                  <MapPin className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  {modalDestinationInput && (
                    <button
                      type="button"
                      onClick={() => {
                        setModalDestinationInput('');
                        setModalRegion('all');
                      }}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Dropdown Menu des destinations */}
                {isDestinationDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-2xl shadow-xl border border-stone-200 p-2 z-30 max-h-56 overflow-y-auto space-y-1">
                    <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-2 py-1">
                      Destinations & terroirs ruraux suggérés :
                    </div>
                    {filteredDestinations.map(d => (
                      <button
                        key={d.name}
                        type="button"
                        onClick={() => {
                          setModalDestinationInput(d.name === 'Toutes les destinations' ? '' : d.name);
                          setModalRegion(d.region);
                          setIsDestinationDropdownOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-[#F3F1E9] transition flex items-center justify-between group cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg bg-stone-100 group-hover:bg-white text-stone-600 flex items-center justify-center shrink-0">
                            <MapPin className="w-3.5 h-3.5 text-[#243E36]" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-stone-800">{d.name}</div>
                            <div className="text-[11px] text-stone-500">{d.desc}</div>
                          </div>
                        </div>
                        <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          {d.region === 'all' ? 'France' : d.region}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Quick tags pills */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[10px] font-semibold text-stone-400">Accès rapide :</span>
                  {['Cévennes', 'Morvan', 'Luberon', 'Pays Basque', 'Drôme'].map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        setModalDestinationInput(tag);
                        setIsDestinationDropdownOpen(false);
                      }}
                      className="px-2.5 py-1 rounded-full bg-stone-100 hover:bg-[#EAE8DF] text-stone-700 text-[11px] font-medium transition cursor-pointer border border-stone-200"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Dates d'arrivée & de départ */}
              <div className="space-y-2 p-4 rounded-2xl bg-stone-50/80 border border-stone-200">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#8C5E45]" />
                    <span>Dates de séjour (Arrivée & Départ)</span>
                  </label>
                  {modalStartDate && modalEndDate && (
                    <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                      {calculateNights(modalStartDate, modalEndDate)} nuit{calculateNights(modalStartDate, modalEndDate) > 1 ? 's' : ''}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <span className="block text-[11px] font-semibold text-stone-500 mb-1">Date d'arrivée</span>
                    <input
                      id="modal-start-date"
                      type="date"
                      value={modalStartDate}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={e => setModalStartDate(e.target.value)}
                      className="w-full text-xs font-semibold text-stone-800 p-2.5 rounded-xl border border-stone-300 focus:border-[#243E36] outline-none bg-white shadow-2xs cursor-pointer"
                    />
                  </div>
                  <div>
                    <span className="block text-[11px] font-semibold text-stone-500 mb-1">Date de départ</span>
                    <input
                      id="modal-end-date"
                      type="date"
                      value={modalEndDate}
                      min={modalStartDate || new Date().toISOString().split('T')[0]}
                      onChange={e => setModalEndDate(e.target.value)}
                      className="w-full text-xs font-semibold text-stone-800 p-2.5 rounded-xl border border-stone-300 focus:border-[#243E36] outline-none bg-white shadow-2xs cursor-pointer"
                    />
                  </div>
                </div>

                {/* Quick Date Presets */}
                <div className="flex items-center gap-2 pt-2 flex-wrap text-[11px]">
                  <span className="text-stone-400 font-medium">Suggestions :</span>
                  <button
                    type="button"
                    onClick={() => {
                      const now = new Date();
                      const day = now.getDay();
                      const daysUntilFriday = (5 - day + 7) % 7 || 7;
                      const friday = new Date(now.getTime() + daysUntilFriday * 86400000);
                      const sunday = new Date(friday.getTime() + 2 * 86400000);
                      setModalStartDate(friday.toISOString().split('T')[0]);
                      setModalEndDate(sunday.toISOString().split('T')[0]);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white border border-stone-200 hover:border-[#243E36] text-stone-700 transition cursor-pointer"
                  >
                    Ce week-end (Ven - Dim)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextSat = new Date(Date.now() + 7 * 86400000);
                      const nextNextSat = new Date(nextSat.getTime() + 7 * 86400000);
                      setModalStartDate(nextSat.toISOString().split('T')[0]);
                      setModalEndDate(nextNextSat.toISOString().split('T')[0]);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white border border-stone-200 hover:border-[#243E36] text-stone-700 transition cursor-pointer"
                  >
                    1 semaine complète
                  </button>
                </div>
              </div>

              {/* 3. Nombre de voyageurs */}
              <div className="p-4 rounded-2xl bg-stone-50/80 border border-stone-200 flex items-center justify-between">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-[#8C5E45]" />
                    <span>Nombre de voyageurs</span>
                  </label>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Adultes et enfants (capacité du gîte rural)
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    disabled={modalGuests <= 1}
                    onClick={() => setModalGuests(prev => Math.max(1, prev - 1))}
                    className="w-9 h-9 rounded-full bg-white border border-stone-300 hover:border-stone-500 flex items-center justify-center font-bold text-stone-700 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer shadow-2xs"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="font-serif font-bold text-base text-stone-900 w-8 text-center">
                    {modalGuests}
                  </span>
                  <button
                    type="button"
                    disabled={modalGuests >= 12}
                    onClick={() => setModalGuests(prev => Math.min(12, prev + 1))}
                    className="w-9 h-9 rounded-full bg-white border border-stone-300 hover:border-stone-500 flex items-center justify-center font-bold text-stone-700 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-4 sm:px-6 py-3.5 sm:py-4 bg-[#FAF9F5] border-t border-stone-200 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setModalDestinationInput('');
                  setModalRegion('all');
                  setModalStartDate('');
                  setModalEndDate('');
                  setModalGuests(1);
                }}
                className="text-xs font-semibold text-stone-600 hover:text-stone-900 underline transition cursor-pointer py-1"
              >
                Tout effacer
              </button>

              <button
                id="airbnb-modal-submit-btn"
                type="button"
                onClick={() => {
                  setFilters(prev => ({
                    ...prev,
                    searchQuery: modalDestinationInput.trim(),
                    region: modalRegion,
                    startDate: modalStartDate,
                    endDate: modalEndDate,
                    guests: modalGuests
                  }));
                  setIsAirbnbModalOpen(false);

                  // Défiler automatiquement vers les hébergements correspondants
                  setTimeout(() => {
                    const resultsEl = document.getElementById('search-results-section') || document.getElementById('marketplace-grid-heading');
                    if (resultsEl) {
                      resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                  }, 120);
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-[#243E36] to-[#182e26] hover:from-[#1b302a] hover:to-[#12231d] text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95"
              >
                <Search className="w-4 h-4 text-[#A3E5C8]" />
                <span>Rechercher les hébergements</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
