import express from 'express';
import cors from 'cors';
import { listingsRouter } from './routes/listings';
import { bookingsRouter } from './routes/bookings';
import { reviewsRouter } from './routes/reviews';
import { messagesRouter } from './routes/messages';
import { systemRouter } from './routes/system';
import { usersRouter } from './routes/users';
import { airtableRouter } from './routes/airtable';

export const app = express();

// Middlewares généraux (support photos base64 jusqu'à 15MB)
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ limit: '15mb', extended: true }));

// Normalisation de l'URL pour Vercel Serverless
app.use((req, _res, next) => {
  const matchedPath = req.headers['x-matched-path'] as string;
  if (matchedPath && (req.url === '/api' || req.url === '/')) {
    req.url = matchedPath;
  }
  next();
});

// 1. API ROUTES (SEPARATION BACKEND)
app.use('/api/listings', listingsRouter);
app.use('/listings', listingsRouter);

app.use('/api/bookings', bookingsRouter);
app.use('/bookings', bookingsRouter);

app.use('/api/reviews', reviewsRouter);
app.use('/reviews', reviewsRouter);

app.use('/api/messages', messagesRouter);
app.use('/messages', messagesRouter);

app.use('/api/users', usersRouter);
app.use('/users', usersRouter);

app.use('/api/airtable', airtableRouter);
app.use('/airtable', airtableRouter);

app.use('/api', systemRouter);

// Endpoint de santé & diagnostic Vercel
app.get(['/api/health', '/health'], (_req, res) => {
  res.json({
    status: 'ok',
    platform: 'MyStay',
    deployment: process.env.VERCEL ? 'vercel_serverless' : 'node_server',
    airtableBase: 'appIt4PVIpjgrmhri',
    timestamp: new Date().toISOString()
  });
});

// Intercepteur 404 strict pour /api/* et /airtable/* pour garantir une réponse JSON et JAMAIS de HTML
app.all(['/api/*', '/airtable/*'], (req, res) => {
  res.status(404).json({
    success: false,
    error: `Route API introuvable : ${req.method} ${req.originalUrl || req.url}`
  });
});

// Middleware d'erreur globale pour les routes API (réponse JSON obligatoire)
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Erreur serveur API:', err);
  if (!res.headersSent) {
    return res.status(err.status || 500).json({
      success: false,
      error: err?.message || 'Erreur interne du serveur'
    });
  }
});

export default app;
