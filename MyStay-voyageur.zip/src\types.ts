export type UserRole = 'voyageur' | 'hote' | 'moderateur' | 'admin';

export type ListingStatus = 'brouillon' | 'en_attente' | 'publiee' | 'a_modifier' | 'rejetee';

export type BookingStatus = 'en_attente_hote' | 'confirmee' | 'refusee' | 'terminee' | 'annulee';

export type MyStayLabel = 'eco_responsable' | 'authentique' | 'accueil_engage' | 'rural_prioritaire';

export type ActiveView = 
  | 'explore' 
  | 'my_trips' 
  | 'host_space' 
  | 'admin_space' 
  | 'moderation_space'
  | 'chat' 
  | 'home' 
  | 'search' 
  | 'host' 
  | 'bookings' 
  | 'admin' 
  | 'cms' 
  | 'stack'
  | 'no_code_stack'
  | 'nocode_inspector';

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatar?: string;
  bio?: string;
  isHostVerified?: boolean;
  isEmailVerified?: boolean;
  role: UserRole;
  createdAt?: string;
  password?: string;
  hostVerificationDocs?: string[];
}

export interface Listing {
  id: string;
  hostId: string;
  hostName: string;
  hostAvatar?: string;
  title: string;
  description: string;
  propertyType: string;
  capacity: number;
  bedrooms: number;
  bathrooms: number;
  pricePerNight: number;
  cleaningFee: number;
  minNights: number;
  maxNights: number;
  bookingMode: 'instant' | 'on_demand';
  cancellationPolicy: 'flexible' | 'moderee' | 'stricte' | 'souple';
  region: string;
  department: string;
  commune: string;
  approxLocation: string;
  exactAddress?: string;
  lat: number;
  lng: number;
  images: string[];
  siteImageUrl?: string;
  videoUrl?: string;
  videos?: string[];
  amenities: string[];
  houseRules: string[];
  localTips?: string;
  sustainablePractices: string[];
  labels: MyStayLabel[];
  status: ListingStatus;
  adminComment?: string;
  modificationRequest?: { requestedAt?: string; details?: string; status?: string } | any;
  submittedAt?: string;
  publishedAt?: string;
  blockedDates: string[];
  rating: number;
  reviewCount: number;
  impactScoreKgCo2SavedPerNight: number;
}

export interface Booking {
  id: string;
  listingId: string;
  listingTitle: string;
  listingImage: string;
  listingCommune: string;
  exactAddress?: string;
  hostId: string;
  hostName: string;
  travelerId: string;
  travelerName: string;
  travelerEmail?: string;
  startDate: string;
  endDate: string;
  nightsCount: number;
  guestsCount: number;
  nightlyTotal: number;
  cleaningFee: number;
  serviceFee: number;
  touristTax: number;
  totalPrice: number;
  hostNetEarnings: number;
  status: BookingStatus;
  paymentStatus?: 'paid' | 'pending' | 'refunded';
  paymentIntentId?: string;
  stripeReceiptUrl?: string;
  accessCode?: string;
  co2SavedKg?: number;
  createdAt: string;
  hasReview?: boolean;
}

export interface Review {
  id: string;
  bookingId: string;
  listingId: string;
  travelerId: string;
  travelerName: string;
  travelerAvatar?: string;
  rating: number;
  subRatings?: {
    cleanliness: number;
    authenticity: number;
    ecoResponsibility: number;
    hostWelcome: number;
  };
  comment: string;
  createdAt: string;
  status?: 'valid' | 'pending' | 'flagged' | 'hidden';
  isFlagged?: boolean;
  hostReply?: {
    text: string;
    date?: string;
    repliedAt?: string;
  };
}

export interface Message {
  id: string;
  bookingId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  content: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  user?: string;
  authorName?: string;
  authorRole?: string;
  targetId?: string;
  targetType?: string;
  details: string;
  severity?: 'info' | 'warning' | 'error';
}

export interface MakeScenarioExecution {
  id: string;
  name?: string;
  scenarioName?: string;
  status: 'success' | 'running' | 'warning' | 'error';
  timestamp: string;
  duration?: string;
  executionTimeMs?: number;
  trigger?: string;
  triggerEvent?: string;
  recordsProcessed?: number;
  payloadSummary?: string;
}

export interface FilterOptions {
  region?: string;
  department?: string;
  propertyType?: string;
  minPrice?: number;
  maxPrice?: number;
  capacity?: number;
  guests?: number;
  startDate?: string;
  endDate?: string;
  sortBy?: string;
  sustainablePractices?: string[];
  selectedSustainableOnly?: boolean;
  labels?: MyStayLabel[];
  searchQuery?: string;
}

export interface NotificationInfo {
  id?: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
  timestamp?: string;
}

export interface PlatformSettings {
  serviceFeePercent: number;
  commissionRatePercent?: number;
  commissionRateHost?: number;
  touristTaxPerNight: number;
  heroTagline: string;
  heroSubtitle: string;
  heroSubheadline?: string;
  charterAnnouncement?: string;
}

export interface EmailAuthReceipt {
  id: string;
  email: string;
  userName?: string;
  userRole?: UserRole;
  validationCode?: string;
  code?: string;
  type?: 'verification' | 'reset';
  status?: string;
  createdAt: string;
  validatedAt?: string;
  expiresAt?: string;
  adminName?: string;
  adminRole?: string;
  adminEmail?: string;
  ipReference?: string;
  securitySignature?: string;
  notes?: string;
}

export interface SustainablePractice {
  id: string;
  category: 'tri' | 'energie_sobriete' | 'produits_locaux' | 'mobilite_douce' | 'sensibilisation_biodiversite';
  label: string;
  description: string;
}

export interface RoleConfig {
  id: UserRole;
  title: string;
  badgeLabel: string;
  badgeStyle: string;
  scope: string;
  description: string;
  powers: string[];
  restrictions: string[];
}

export const ROLES_CONFIG: Record<UserRole, RoleConfig> = {
  voyageur: {
    id: 'voyageur',
    title: 'Voyageur',
    badgeLabel: 'Voyageur',
    badgeStyle: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    scope: 'Espace Voyageur uniquement',
    description: 'Une fois inscrit, ne voit que la partie qui le concerne : exploration, ses voyages, ses réservations et ses avis.',
    powers: [
      'Recherche et filtrage du catalogue rural',
      'Réservation en ligne et paiement sécurisé',
      'Accès à son historique de séjours personnels',
      'Messagerie directe avec ses hôtes',
      'Dépôt d’avis certifié après séjour'
    ],
    restrictions: [
      'Aucun accès à l’espace gestion d’hébergements hôte',
      'Aucun accès à la console de modération ou supervision',
      'Aucun accès aux réservations des autres membres'
    ]
  },
  hote: {
    id: 'hote',
    title: 'Hôte Rural',
    badgeLabel: 'Hôte rural',
    badgeStyle: 'bg-amber-100 text-amber-800 border-amber-300',
    scope: 'Espace Hôte uniquement',
    description: 'Une fois inscrit, ne voit que la partie qui le concerne : la gestion de ses gîtes, ses réservations reçues et ses revenus.',
    powers: [
      'Création et soumission d’annonces de gîtes ruraux',
      'Gestion de son calendrier de disponibilités et blocage de dates',
      'Acceptation ou refus des demandes de réservation reçues',
      'Suivi de ses gains nets et coordonnées des voyageurs',
      'Réponses aux avis déposés sur ses hébergements'
    ],
    restrictions: [
      'Gestion limitée exclusivement à ses propres hébergements',
      'Aucun accès à la console de supervision ou modération',
      'Aucun pouvoir d’attribution de rôles ou de validation d’autres gîtes'
    ]
  },
  moderateur: {
    id: 'moderateur',
    title: 'Modérateur (Superviseur & Médiateur)',
    badgeLabel: 'Superviseur / Modérateur',
    badgeStyle: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    scope: 'Vue globale Hôte & Voyageur + Arbitrage',
    description: 'Superviseur neutre entre l’hôte et le voyageur avec une vue globale sur les deux. Interagit sur leurs actions (modération, arbitrage, conciliation).',
    powers: [
      'Vue globale sur toutes les annonces soumises par tous les hôtes',
      'Validation, rejet ou demande d’ajustement des fiches d’hébergements',
      'Attribution et contrôle des labels éco-responsables de la charte',
      'Vue globale sur toutes les réservations voyageurs/hôtes de la plateforme',
      'Médiation officielle dans les conversations de séjour en cas de litige',
      'Libération de dates bloquées ou arbitrage des annulations litigieuses',
      'Modération de tous les avis voyageurs et des réponses hôtes',
      'Mode inspection double : inspection vue hôte et inspection vue voyageur'
    ],
    restrictions: [
      'Ne peut pas modifier les rôles ni donner d’attributions (réservé Super Admin)',
      'Ne peut pas supprimer des utilisateurs de la plateforme',
      'Ne peut pas modifier les paramètres système économiques (commissions, taxes)',
      'Ne peut pas créer de profils administrateurs'
    ]
  },
  admin: {
    id: 'admin',
    title: 'Super Administrateur',
    badgeLabel: 'Super Admin (Plein Pouvoir)',
    badgeStyle: 'bg-stone-900 text-stone-100 border-stone-700',
    scope: 'Vue globale sur tout le monde + Contrôle total',
    description: 'A la main sur tout : vue globale sur tout le monde, peut créer des utilisateurs et donner des attributions de rôles.',
    powers: [
      'Contrôle absolu et vue globale sur tous les utilisateurs et données',
      'Création de tout type de compte (Voyageur, Hôte, Modérateur, Admin)',
      'Attribution dynamique des rôles et modification des permissions',
      'Suppression de comptes utilisateurs et révocation d’accès',
      'Configuration éditoriale et économique (taux de commission %, taxes)',
      'Gestion complète des bases de données (Supabase, Airtable Sync)',
      'Accès au journal d’audit de sécurité complet et aux logs système',
      'Exportation générale des données (CSV, Supabase, Airtable)'
    ],
    restrictions: [
      'Aucune restriction technique : détient le plein pouvoir sur la plateforme'
    ]
  }
};

