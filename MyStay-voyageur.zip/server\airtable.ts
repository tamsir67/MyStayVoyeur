import dotenv from 'dotenv';
dotenv.config();
import fs from 'fs';
import path from 'path';
import { inMemoryListings, inMemoryBookings, inMemoryUsers, inMemoryReviews, inMemoryMessages, dbService } from './db';
import { Listing, Booking, User, Review, Message, } from '../src/types';

export interface AirtableLog {
  id: string;
  timestamp: string;
  action: 'TEST' | 'PUSH' | 'PULL' | 'AUTO_SYNC' | 'IMPORT';
  status: 'success' | 'error' | 'warning';
  table: string;
  recordsCount?: number;
  durationMs: number;
  details: string;
}

export interface AirtableConfig {
  baseId: string;
  token: string;
  inviteLink?: string;
  syncMode: 'airtable' | 'supabase' | 'local';
  autoSync: boolean;
  lastSyncAt: string | null;
  lastSyncStatus: 'idle' | 'success' | 'error';
  tables: {
    listings: string;
    bookings: string;
    users: string;
    reviews: string;
    messages: string;
  };
}

const CONFIG_FILE = path.join(process.cwd(), '.airtable_config.json');

// Base ID fourni par l'utilisateur
const DEFAULT_BASE_ID = 'appIt4PVIpjgrmhri';
const DEFAULT_INVITE_LINK = 'https://airtable.com/invite/l?inviteId=invE7uhJB3I0Ntbbi&inviteToken=e6a9b9e4e548765afa0cee1eb3729fcf9c2360cf3c2a631fe8ab1fef3e148714';

let airtableConfig: AirtableConfig = loadStoredConfig();
let airtableLogs: AirtableLog[] = [
  {
    id: `log_init_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'TEST',
    status: 'warning',
    table: 'system',
    durationMs: 0,
    details: `Base Airtable configurée avec l'ID ${DEFAULT_BASE_ID}. En attente du Personal Access Token (PAT) pour synchronisation API bidirectionnelle.`
  }
];

function loadStoredConfig(): AirtableConfig {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
      return {
        baseId: data.baseId || process.env.AIRTABLE_BASE_ID || DEFAULT_BASE_ID,
        token: data.token || process.env.AIRTABLE_PERSONAL_ACCESS_TOKEN || process.env.AIRTABLE_TOKEN || process.env.AIRTABLE_PAT || process.env.AIRTABLE_API_KEY || '',
        inviteLink: data.inviteLink || DEFAULT_INVITE_LINK,
        syncMode: data.syncMode || 'airtable',
        autoSync: data.autoSync ?? true,
        lastSyncAt: data.lastSyncAt || null,
        lastSyncStatus: data.lastSyncStatus || 'idle',
        tables: {
          listings: data.tables?.listings || 'Listings',
          bookings: data.tables?.bookings || 'Bookings',
          users: data.tables?.users || 'profiles',
          reviews: data.tables?.reviews || 'Reviews',
          messages: data.tables?.messages || 'Messages',
        }
      };
    }
  } catch (e) {
    console.warn('Notice: impossible de charger .airtable_config.json:', e);
  }

  return {
    baseId: process.env.AIRTABLE_BASE_ID || DEFAULT_BASE_ID,
    token: process.env.AIRTABLE_PERSONAL_ACCESS_TOKEN || process.env.AIRTABLE_TOKEN || process.env.AIRTABLE_PAT || process.env.AIRTABLE_API_KEY || '',
    inviteLink: DEFAULT_INVITE_LINK,
    syncMode: 'airtable',
    autoSync: true,
    lastSyncAt: null,
    lastSyncStatus: 'idle',
    tables: {
      listings: 'Listings',
      bookings: 'Bookings',
      messages: 'Messages',
      users: 'profiles',
      reviews: 'Reviews',
    }
  };
}

function saveStoredConfig() {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(airtableConfig, null, 2), 'utf-8');
  } catch (e) {
    console.warn('Notice: impossible de sauvegarder .airtable_config.json:', e);
  }
}

function addLog(action: AirtableLog['action'], status: AirtableLog['status'], table: string, durationMs: number, details: string, recordsCount?: number) {
  const log: AirtableLog = {
    id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    action,
    status,
    table,
    recordsCount,
    durationMs,
    details
  };
  airtableLogs = [log, ...airtableLogs.slice(0, 49)];
}

// Transformateurs MyStay -> Airtable Fields
export function listingToAirtableFields(l: Listing) {
  return {
    id: l.id,
    title: l.title,
    description: l.description || '',
    price_per_night: Number(l.pricePerNight),
    commune: l.commune,
    department: l.department,
    region: l.region,
    lat: Number(l.lat || 0),
    lng: Number(l.lng || 0),
    capacity: Number(l.capacity || 2),
    bedrooms: Number(l.bedrooms || 1),
    bathrooms: Number(l.bathrooms || 1),
    labels: (l.labels || []).join(', '),
    amenities: (l.amenities || []).join(', '),
    images: (l.images || []).join('\n'),
    host_id: l.hostId,
    host_name: l.hostName,
    rating: Number(l.rating || 5),
    review_count: Number(l.reviewCount || 0),
    status: l.status || 'publiee',
    cleaning_fee: Number(l.cleaningFee || 0),
    blocked_dates: (l.blockedDates || []).join(', '),
    min_nights: Number(l.minNights || 1),
    max_nights: Number(l.maxNights || 30),
    booking_mode: l.bookingMode || 'instant',
    cancellation_policy: l.cancellationPolicy || 'moderee',
    exact_address: l.exactAddress || '',
    approx_location: l.approxLocation || '',
    property_type: l.propertyType || 'gite',
    local_tips: l.localTips || '',
    house_rules: (l.houseRules || []).join(', '),
    sustainable_practices: (l.sustainablePractices || []).join(', ')
  };
}

export function bookingToAirtableFields(b: Booking) {
  return {
    id: b.id,
    listing_id: b.listingId,
    listing_title: b.listingTitle,
    listing_commune: b.listingCommune || '',
    traveler_id: b.travelerId,
    traveler_name: b.travelerName,
    traveler_email: b.travelerEmail,
    host_id: b.hostId,
    host_name: b.hostName,
    start_date: b.startDate,
    end_date: b.endDate,
    nights_count: Number(b.nightsCount),
    guests_count: Number(b.guestsCount),
    total_price: Number(b.totalPrice),
    host_net_earnings: Number(b.hostNetEarnings || b.totalPrice * 0.9),
    status: b.status,
    payment_status: b.paymentStatus,
    created_at: b.createdAt
  };
}

export function userToAirtableFields(u: User) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    avatar: u.avatar || '',
    phone: u.phone || '',
    bio: u.bio || '',
    is_host_verified: Boolean(u.isHostVerified),
    is_email_verified: Boolean(u.isEmailVerified),
    created_at: u.createdAt || new Date().toISOString()
  };
}

export function reviewToAirtableFields(r: Review) {
  return {
    id: r.id,
    listing_id: r.listingId,
    traveler_name: r.travelerName,
    rating: Number(r.rating),
    comment: r.comment,
    created_at: r.createdAt
  };
}

export function messageToAirtableFields(m: Message) {
  return {
    id: m.id,
    booking_id: m.bookingId,
    sender_id: m.senderId,
    sender_name: m.senderName,
    sender_role: m.senderRole,
    content: m.content,
    created_at: m.timestamp
  };
}

export function airtableFieldsToMessage(fields: any, recordId?: string): Message {
  return {
    id: fields.id || recordId || `msg_${Date.now()}`,
    bookingId: fields.booking_id || fields.bookingId || '',
    senderId: fields.sender_id || fields.senderId || '',
    senderName: fields.sender_name || fields.senderName || 'Utilisateur',
    senderRole: fields.sender_role || fields.senderRole || 'voyageur',
    content: fields.content || '',
    timestamp: fields.timestamp || new Date().toISOString()
  };
}

export function airtableFieldsToListing(fields: any, recordId?: string): Listing {
  const images = Array.isArray(fields.images)
    ? fields.images.map((img: any) => typeof img === 'string' ? img : img.url || '').filter(Boolean)
    : typeof fields.images === 'string' && fields.images.trim()
    ? fields.images.split(/[,;\n]/).map((s: string) => s.trim()).filter(Boolean)
    : ['https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80'];

  const amenities = Array.isArray(fields.amenities)
    ? fields.amenities
    : typeof fields.amenities === 'string' && fields.amenities.trim()
    ? fields.amenities.split(/[,;]/).map((s: string) => s.trim()).filter(Boolean)
    : ['Cuisine équipée', 'Wi-Fi bas débit', 'Terrasse ombragée'];

  const houseRules = Array.isArray(fields.house_rules || fields.houseRules)
    ? (fields.house_rules || fields.houseRules)
    : typeof (fields.house_rules || fields.houseRules) === 'string'
    ? (fields.house_rules || fields.houseRules).split(/[,;]/).map((s: string) => s.trim()).filter(Boolean)
    : ['Respect du calme de la nature', 'Tri rigoureux des déchets'];

  const sustainablePractices = Array.isArray(fields.sustainable_practices || fields.sustainablePractices)
    ? (fields.sustainable_practices || fields.sustainablePractices)
    : typeof (fields.sustainable_practices || fields.sustainablePractices) === 'string'
    ? (fields.sustainable_practices || fields.sustainablePractices).split(/[,;]/).map((s: string) => s.trim()).filter(Boolean)
    : ['Tri sélectif & compostage autonome', 'Énergie 100% renouvelable', 'Panier terroir local'];

  const labels = Array.isArray(fields.labels)
    ? fields.labels
    : typeof fields.labels === 'string' && fields.labels.trim()
    ? fields.labels.split(/[,;]/).map((s: string) => s.trim()).filter(Boolean)
    : ['eco_responsable'];

  const blockedDates = Array.isArray(fields.blocked_dates || fields.blockedDates)
    ? (fields.blocked_dates || fields.blockedDates)
    : typeof (fields.blocked_dates || fields.blockedDates) === 'string'
    ? (fields.blocked_dates || fields.blockedDates).split(/[,;]/).map((s: string) => s.trim()).filter(Boolean)
    : [];

  return {
    id: fields.id || recordId || `lst_${Date.now()}`,
    title: fields.title || 'Hébergement rural MyStay',
    description: fields.description || 'Lieu rural authentique engagé pour la préservation du patrimoine.',
    propertyType: fields.property_type || fields.propertyType || 'gite',
    capacity: Number(fields.capacity || fields.max_guests) || 4,
    bedrooms: Number(fields.bedrooms) || 2,
    bathrooms: Number(fields.bathrooms) || 1,
    pricePerNight: Number(fields.price_per_night || fields.pricePerNight) || 85,
    cleaningFee: Number(fields.cleaning_fee || fields.cleaningFee) || 25,
    minNights: Number(fields.min_nights || fields.minNights) || 2,
    maxNights: Number(fields.max_nights || fields.maxNights) || 30,
    bookingMode: fields.booking_mode || fields.bookingMode || 'instant',
    cancellationPolicy: fields.cancellation_policy || fields.cancellationPolicy || 'moderee',
    region: fields.region || 'Occitanie',
    department: fields.department || 'Lozère (48)',
    commune: fields.commune || 'Saint-Germain-de-Calberte',
    approxLocation: fields.approx_location || fields.approxLocation || 'En pleine nature préservée',
    exactAddress: fields.exact_address || fields.exactAddress || 'Chemin rural communal',
    lat: Number(fields.latitude || fields.lat) || 44.218,
    lng: Number(fields.longitude || fields.lng) || 3.809,
    images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80'],
    siteImageUrl: images[0] || 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80',
    videoUrl: fields.video_url || fields.videoUrl || undefined,
    videos: fields.video_url || fields.videoUrl ? [fields.video_url || fields.videoUrl] : [],
    amenities,
    houseRules,
    localTips: fields.local_tips || fields.localTips || 'Visite des producteurs locaux et randonnées au crépuscule.',
    sustainablePractices: sustainablePractices.length >= 3 ? sustainablePractices : [...sustainablePractices, 'Tri sélectif & compostage autonome', 'Énergie 100% renouvelable', 'Panier terroir local'].slice(0, 3),
    labels: labels.length > 0 ? labels : ['eco_responsable'],
    status: fields.status || 'publiee',
    hostId: fields.host_id || fields.hostId || 'usr_hote_1',
    hostName: fields.host_name || fields.hostName || 'Hôte rural MyStay',
    hostAvatar: fields.host_avatar || fields.hostAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    rating: Number(fields.rating) || 5.0,
    reviewCount: Number(fields.review_count || fields.reviewCount) || 1,
    blockedDates,
    impactScoreKgCo2SavedPerNight: Number(fields.impact_score_co2 || fields.impactScoreKgCo2SavedPerNight) || 8.5,
    submittedAt: fields.submitted_at || fields.submittedAt || new Date().toISOString(),
    publishedAt: fields.published_at || fields.publishedAt || new Date().toISOString()
  };
}

export function airtableFieldsToBooking(fields: any, recordId?: string): Booking {
  return {
    id: fields.id || recordId || `res_${Date.now()}`,
    listingId: fields.listing_id || fields.listingId || 'lst_mas_cevenol',
    listingTitle: fields.listing_title || fields.listingTitle || 'Hébergement rural',
    listingImage: fields.listing_image || fields.listingImage || 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    listingCommune: fields.listing_commune || fields.listingCommune || 'Cévennes',
    exactAddress: fields.exact_address || fields.exactAddress || 'Chemin rural',
    hostId: fields.host_id || fields.hostId || 'usr_hote_1',
    hostName: fields.host_name || fields.hostName || 'Hôte rural',
    travelerId: fields.traveler_id || fields.travelerId || 'usr_voyageur_1',
    travelerName: fields.traveler_name || fields.travelerName || 'Voyageur MyStay',
    travelerEmail: fields.traveler_email || fields.travelerEmail || 'voyageur@mystay.fr',
    startDate: fields.start_date || fields.startDate || '2026-10-10',
    endDate: fields.end_date || fields.endDate || '2026-10-14',
    nightsCount: Number(fields.nights_count || fields.nightsCount) || 4,
    guestsCount: Number(fields.guests_count || fields.guestsCount) || 2,
    nightlyTotal: Number(fields.nightly_total || fields.nightlyTotal) || 360,
    cleaningFee: Number(fields.cleaning_fee || fields.cleaningFee) || 30,
    serviceFee: Number(fields.service_fee || fields.serviceFee) || 43.2,
    touristTax: Number(fields.tourist_tax || fields.touristTax) || 12,
    totalPrice: Number(fields.total_price || fields.totalPrice) || 445.2,
    hostNetEarnings: Number(fields.host_net_earnings || fields.hostNetEarnings) || 379.2,
    status: fields.status || 'confirmee',
    paymentStatus: fields.payment_status || fields.paymentStatus || 'paid',
    accessCode: fields.access_code || fields.accessCode || 'MYSTAY-1234',
    co2SavedKg: Number(fields.co2_saved_kg || fields.co2SavedKg) || 34,
    createdAt: fields.created_at || fields.createdAt || new Date().toISOString(),
    hasReview: Boolean(fields.has_review || fields.hasReview)
  };
}

// Service Airtable
export const airtableService = {
  getConfig() {
    return {
      ...airtableConfig,
      hasToken: Boolean(airtableConfig.token && airtableConfig.token.trim().length > 0),
      maskedToken: airtableConfig.token 
        ? `${airtableConfig.token.slice(0, 7)}...${airtableConfig.token.slice(-4)}` 
        : null,
      stats: {
        listings: inMemoryListings.length,
        bookings: inMemoryBookings.length,
        users: inMemoryUsers.length,
        reviews: inMemoryReviews.length,
        messages: inMemoryMessages.length
      }
    };
  },

  getLogs() {
    return airtableLogs;
  },

  updateConfig(updates: Partial<AirtableConfig>) {
    airtableConfig = {
      ...airtableConfig,
      ...updates
    };
    if (updates.token) {
      process.env.AIRTABLE_API_KEY = updates.token;
      process.env.AIRTABLE_PAT = updates.token;
    }
    if (updates.baseId) {
      process.env.AIRTABLE_BASE_ID = updates.baseId;
    }
    saveStoredConfig();
    return this.getConfig();
  },

  async testConnection(baseId?: string, token?: string): Promise<{
    success: boolean;
    message: string;
    accessibleTables: string[];
    missingTables: string[];
    tablesStatus?: Record<string, boolean>;
    statusCode?: number;
    details?: any;
  }> {
    const bId = (baseId || airtableConfig.baseId || DEFAULT_BASE_ID).trim();
    const tok = (token || airtableConfig.token || '').trim();
    const startTime = Date.now();

    if (!tok) {
      const msg = "Clé d'accès Airtable manquante. Pour connecter l'API, créez un Personal Access Token (PAT) sur airtable.com/create/tokens ou utilisez l'export CSV 1-clic.";
      addLog('TEST', 'warning', 'all', 0, msg);
      return {
        success: false,
        message: msg,
        accessibleTables: [],
        missingTables: ['Listings', 'Bookings', 'Users', 'Reviews'],
        statusCode: 401
      };
    }

    try {
      // 1. Tester la liste des tables ou interroger la table Listings
      const candidateTables = ['Listings', 'Hébergements', 'Bookings', 'Réservations', 'Users', 'Utilisateurs', 'Reviews', 'Avis', 'messages'];
      const accessibleTables: string[] = [];
      const tablesStatus: Record<string, boolean> = {};

      // Tester Listings
      const testListingsUrl = `https://api.airtable.com/v0/${bId}/Listings?maxRecords=1`;
      const res = await fetch(testListingsUrl, {
        headers: {
          'Authorization': `Bearer ${tok}`,
          'Content-Type': 'application/json'
        }
      });

      const duration = Date.now() - startTime;

      if (res.status === 401 || res.status === 403) {
        const errorData = await res.json().catch(() => ({}));
        const msg = `Erreur d'authentification Airtable (${res.status}): Vérifiez que le Token PAT possède bien les scopes 'data.records:read' et 'data.records:write' avec accès à la base '${bId}'.`;
        addLog('TEST', 'error', 'all', duration, msg);
        return {
          success: false,
          message: msg,
          accessibleTables: [],
          missingTables: ['Listings', 'Bookings', 'Users', 'Reviews', 'Messages'],
          statusCode: res.status,
          details: errorData
        };
      }

      if (res.status === 404) {
        // La table "Listings" n'existe peut-être pas avec ce nom exact
        addLog('TEST', 'warning', 'Listings', duration, `Table 'Listings' non trouvée directement dans la base ${bId}. Vous pouvez créer la table ou importer le CSV.`);
        return {
          success: true,
          message: `Connexion à Airtable authentifiée avec succès ! La base ${bId} répond. Il reste à créer les tables (Listings, Bookings, Users, Reviews,Messages) ou à utiliser le bouton de synchronisation pour les peupler.`,
          accessibleTables: [],
          missingTables: ['Listings', 'Bookings', 'Users', 'Reviews'],
          statusCode: 200
        };
      }

      if (res.ok) {
        accessibleTables.push('Listings');
        tablesStatus['Listings'] = true;
      }

      // Tester Bookings
      try {
        const testBookingsUrl = `https://api.airtable.com/v0/${bId}/Bookings?maxRecords=1`;
        const bRes = await fetch(testBookingsUrl, {
          headers: { 'Authorization': `Bearer ${tok}` }
        });
        if (bRes.ok) accessibleTables.push('Bookings');
      } catch {}

      // Tester Profiles / Users
      try {
        const usersTable = airtableConfig.tables.users || 'profiles';
        const testUsersUrl = `https://api.airtable.com/v0/${bId}/${encodeURIComponent(usersTable)}?maxRecords=1`;
        const uRes = await fetch(testUsersUrl, {
          headers: { 'Authorization': `Bearer ${tok}` }
        });
        if (uRes.ok) accessibleTables.push(usersTable);
      } catch {}

      // Tester Reviews
      try {
        const testReviewsUrl = `https://api.airtable.com/v0/${bId}/Reviews?maxRecords=1`;
        const rRes = await fetch(testReviewsUrl, {
          headers: { 'Authorization': `Bearer ${tok}` }
        });
        if (rRes.ok) accessibleTables.push('Reviews');
      } catch {}

      // Tester Messages
      try {
        const testMessagesUrl = `https://api.airtable.com/v0/${bId}/${encodeURIComponent(airtableConfig.tables.messages || 'Messages')}?maxRecords=1`;
        const mRes = await fetch(testMessagesUrl, {
          headers: { 'Authorization': `Bearer ${tok}` }
        });
        if (mRes.ok) accessibleTables.push('Messages');
      } catch {}

      const msg = `Connexion réussie à Airtable (${bId}) ! Tables détectées : ${accessibleTables.length > 0 ? accessibleTables.join(', ') : 'Aucune table existante détectée'}.`;
      addLog('TEST', 'success', 'all', duration, msg);

      return {
        success: true,
        message: msg,
        accessibleTables,
        missingTables: [
          airtableConfig.tables.listings || 'Listings',
          airtableConfig.tables.bookings || 'Bookings',
          airtableConfig.tables.users || 'profiles',
          airtableConfig.tables.reviews || 'Reviews',
          airtableConfig.tables.messages || 'Messages'
        ].filter(t => !accessibleTables.includes(t)),
        statusCode: 200,
        tablesStatus
      };
    } catch (err: any) {
      const duration = Date.now() - startTime;
      const msg = `Erreur réseau lors de la connexion à Airtable : ${err.message}`;
      addLog('TEST', 'error', 'network', duration, msg);
      return {
        success: false,
        message: msg,
        accessibleTables: [],
        missingTables: ['Listings', 'Bookings', 'Users', 'Reviews', 'Messages'],
        statusCode: 500
      };
    }
  },

  // Synchronisation PUSH : Envoyer les données de MyStay vers Airtable
  async pushAllToAirtable(): Promise<{
    success: boolean;
    message: string;
    syncedCounts: { listings: number; bookings: number; users: number; reviews: number; messages: number };
    errors: string[];
  }> {
    const bId = (airtableConfig.baseId || DEFAULT_BASE_ID).trim();
    const tok = (airtableConfig.token || '').trim();
    const errors: string[] = [];
    const syncedCounts = { listings: 0, bookings: 0, users: 0, reviews: 0, messages: 0 };

    if (!tok) {
      const counts = {
        listings: inMemoryListings.length,
        bookings: inMemoryBookings.length,
        users: inMemoryUsers.length,
        reviews: inMemoryReviews.length,
        messages: inMemoryMessages.length
      };
      airtableConfig.lastSyncAt = new Date().toISOString();
      airtableConfig.lastSyncStatus = 'success';
      saveStoredConfig();
      addLog('PUSH', 'warning', 'all', 12, `Données sauvegardées avec succès (${counts.listings} annonces, ${counts.bookings} réservations). Clé Token Airtable non configurée : synchronisation distante en attente du Personal Access Token.`);
      return {
        success: true,
        message: `Synchronisation locale réussie ! Vos données (${counts.listings} annonces, ${counts.bookings} réservations, ${counts.messages} messages) sont sauvegardées et opérationnelles. Pour synchroniser automatiquement en direct avec la base distante Airtable ${bId}, ajoutez votre Personal Access Token.`,
        syncedCounts: counts,
        errors: []
      };
    }

    const startTime = Date.now();

    // 1. Pousser les Listings
    try {
      const records = inMemoryListings.map(l => ({ fields: listingToAirtableFields(l) }));
      const count = await batchUpsertToAirtable(bId, tok, airtableConfig.tables.listings || 'Listings', records);
      syncedCounts.listings = count;
      addLog('PUSH', 'success', 'Listings', Date.now() - startTime, `${count} hébergements synchronisés vers Airtable`, count);
    } catch (e: any) {
      errors.push(`Table Listings: ${e.message}`);
      addLog('PUSH', 'error', 'Listings', Date.now() - startTime, `Erreur push Listings: ${e.message}`);
    }

    // 2. Pousser les Bookings
    try {
      const records = inMemoryBookings.map(b => ({ fields: bookingToAirtableFields(b) }));
      const count = await batchUpsertToAirtable(bId, tok, airtableConfig.tables.bookings || 'Bookings', records);
      syncedCounts.bookings = count;
      addLog('PUSH', 'success', 'Bookings', Date.now() - startTime, `${count} réservations synchronisées vers Airtable`, count);
    } catch (e: any) {
      errors.push(`Table Bookings: ${e.message}`);
      addLog('PUSH', 'error', 'Bookings', Date.now() - startTime, `Erreur push Bookings: ${e.message}`);
    }

    // 3. Pousser les Users
    try {
      const records = inMemoryUsers.map(u => ({ fields: userToAirtableFields(u) }));
      const count = await batchUpsertToAirtable(bId, tok, airtableConfig.tables.users || 'Users', records);
      syncedCounts.users = count;
      addLog('PUSH', 'success', 'Users', Date.now() - startTime, `${count} utilisateurs synchronisés vers Airtable`, count);
    } catch (e: any) {
      errors.push(`Table Users: ${e.message}`);
      addLog('PUSH', 'error', 'Users', Date.now() - startTime, `Erreur push Users: ${e.message}`);
    }

    // 4. Pousser les Reviews
    try {
      const records = inMemoryReviews.map(r => ({ fields: reviewToAirtableFields(r) }));
      const count = await batchUpsertToAirtable(bId, tok, airtableConfig.tables.reviews || 'Reviews', records);
      syncedCounts.reviews = count;
      addLog('PUSH', 'success', 'Reviews', Date.now() - startTime, `${count} avis synchronisés vers Airtable`, count);
    } catch (e: any) {
      errors.push(`Table Reviews: ${e.message}`);
      addLog('PUSH', 'error', 'Reviews', Date.now() - startTime, `Erreur push Reviews: ${e.message}`);
    }

    // 5. Pousser les Messages
    try {
      const records = inMemoryMessages.map(m => ({ fields: messageToAirtableFields(m) }));
      const count = await batchUpsertToAirtable(bId, tok, airtableConfig.tables.messages || 'Messages', records);
      syncedCounts.messages = count;
      addLog('PUSH', 'success', 'Messages', Date.now() - startTime, `${count} messages synchronisés vers Airtable`, count);
    } catch (e: any) {
      errors.push(`Table Messages: ${e.message}`);
      addLog('PUSH', 'error', 'Messages', Date.now() - startTime, `Erreur push Messages: ${e.message}`);
    }

    const totalSynced = syncedCounts.listings + syncedCounts.bookings + syncedCounts.users + syncedCounts.reviews + syncedCounts.messages;
    const isSuccess = totalSynced > 0;

    airtableConfig.lastSyncAt = new Date().toISOString();
    airtableConfig.lastSyncStatus = isSuccess ? 'success' : 'error';
    saveStoredConfig();

    return {
      success: isSuccess,
      message: isSuccess 
        ? `Synchronisation terminée avec succès ! ${totalSynced} enregistrements synchronisés dans la base Airtable ${bId}.`
        : `La synchronisation a rencontré des blocages : ${errors.join(' | ')}. Assurez-vous d'avoir créé les tables correspondantes dans Airtable.`,
      syncedCounts,
      errors
    };
  },

  // Synchronisation PULL : Importer les données depuis Airtable vers MyStay
  async pullAllFromAirtable(): Promise<{
    success: boolean;
    message: string;
    importedCounts: { listings: number; bookings: number; users: number; reviews: number; messages: number };
    errors: string[];
  }> {
    const bId = (airtableConfig.baseId || DEFAULT_BASE_ID).trim();
    const tok = (airtableConfig.token || '').trim();
    const errors: string[] = [];
    const importedCounts = { listings: 0, bookings: 0, users: 0, reviews: 0, messages: 0 };

    if (!tok) {
      const counts = {
        listings: inMemoryListings.length,
        bookings: inMemoryBookings.length,
        users: inMemoryUsers.length,
        reviews: inMemoryReviews.length,
        messages: inMemoryMessages.length
      };
      addLog('PULL', 'warning', 'all', 12, `Données rechargées depuis la persistance locale (${counts.listings} annonces, ${counts.bookings} réservations). Clé Token Airtable non configurée.`);
      return {
        success: true,
        message: `Données locales rechargées avec succès (${counts.listings} annonces, ${counts.bookings} réservations, ${counts.messages} messages). Pour importer directement depuis votre base distante Airtable ${bId}, ajoutez votre Personal Access Token.`,
        importedCounts: counts,
        errors: []
      };
    }

    const startTime = Date.now();

    // 1. Lire Listings
    try {
      const records = await fetchAllFromAirtable(bId, tok, airtableConfig.tables.listings || 'Listings');
      if (records.length > 0) {
        const mappedListings = records.map(r => airtableFieldsToListing(r.fields || r, r.id));
        dbService.bulkUpsertListings(mappedListings);
        importedCounts.listings = records.length;
        addLog('PULL', 'success', 'Listings', Date.now() - startTime, `${records.length} hébergements importés depuis Airtable`, records.length);
      }
    } catch (e: any) {
      errors.push(`Table Listings: ${e.message}`);
    }

    // 2. Lire Bookings
    try {
      const records = await fetchAllFromAirtable(bId, tok, airtableConfig.tables.bookings || 'Bookings');
      if (records.length > 0) {
        const mappedBookings = records.map(r => airtableFieldsToBooking(r.fields || r, r.id));
        dbService.bulkUpsertBookings(mappedBookings);
        importedCounts.bookings = records.length;
        addLog('PULL', 'success', 'Bookings', Date.now() - startTime, `${records.length} réservations importées depuis Airtable`, records.length);
      }
    } catch (e: any) {
      errors.push(`Table Bookings: ${e.message}`);
    }

    // 3. Lire Users
    try {
      const records = await fetchAllFromAirtable(bId, tok, airtableConfig.tables.users || 'Users');
      if (records.length > 0) {
        const mappedUsers = records.map(r => ({
          id: r.fields.id || r.id,
          name: r.fields.name || 'Utilisateur',
          email: r.fields.email || '',
          role: r.fields.role || 'voyageur',
          phone: r.fields.phone || '',
          bio: r.fields.bio || '',
          avatar: r.fields.avatar || '',
          isHostVerified: Boolean(r.fields.is_host_verified),
          isEmailVerified: Boolean(r.fields.is_email_verified),
          createdAt: r.fields.created_at || new Date().toISOString()
        } as User));
        dbService.bulkUpsertUsers(mappedUsers);
        importedCounts.users = records.length;
        addLog('PULL', 'success', 'Users', Date.now() - startTime, `${records.length} utilisateurs importés depuis Airtable`, records.length);
      }
    } catch (e: any) {
      errors.push(`Table Users: ${e.message}`);
    }

    // 4. Lire Reviews
    try {
      const records = await fetchAllFromAirtable(bId, tok, airtableConfig.tables.reviews || 'Reviews');
      if (records.length > 0) {
        const mappedReviews = records.map(r => ({
          id: r.fields.id || r.id,
          bookingId: r.fields.booking_id || r.fields.bookingId || '',
          listingId: r.fields.listing_id || '',
          travelerId: r.fields.traveler_id || '',
          travelerName: r.fields.traveler_name || 'Voyageur',
          rating: Number(r.fields.rating) || 5,
          comment: r.fields.comment || '',
          createdAt: r.fields.date || r.fields.created_at || new Date().toISOString()
        } as Review));
        dbService.bulkUpsertReviews(mappedReviews);
        importedCounts.reviews = records.length;
        addLog('PULL', 'success', 'Reviews', Date.now() - startTime, `${records.length} avis importés depuis Airtable`, records.length);
      }
    } catch (e: any) {
      errors.push(`Table Reviews: ${e.message}`);
    }

    // 5. Lire Messages
    try {
      const records = await fetchAllFromAirtable(bId, tok, airtableConfig.tables.messages || 'Messages');
      if (records.length > 0) {
        const mappedMessages = records.map(r => airtableFieldsToMessage(r.fields || r, r.id));
        dbService.bulkUpsertMessages(mappedMessages);
        importedCounts.messages = records.length;
        addLog('PULL', 'success', 'Messages', Date.now() - startTime, `${records.length} messages importés depuis Airtable`, records.length);
      }
    } catch (e: any) {
      errors.push(`Table Messages: ${e.message}`);
    }

    const totalImported = importedCounts.listings + importedCounts.bookings + importedCounts.users + importedCounts.reviews + importedCounts.messages;
    return {
      success: totalImported > 0 || errors.length === 0,
      message: `${totalImported} enregistrements récupérés et injectés dans la plateforme.`,
      importedCounts,
      errors
    };
  },

  getTableName(table: 'Listings' | 'Bookings' | 'Messages' | 'Users' | 'Reviews'): string {
    if (table === 'Listings') return airtableConfig.tables.listings || 'Listings';
    if (table === 'Bookings') return airtableConfig.tables.bookings || 'Bookings';
    if (table === 'Users') return airtableConfig.tables.users || 'profiles';
    if (table === 'Reviews') return airtableConfig.tables.reviews || 'Reviews';
    if (table === 'Messages') return airtableConfig.tables.messages || 'Messages';
    return table;
  },

  // Auto-sync unitaire en temps réel lors de toute création ou modification
  async triggerAutoSync(table: 'Listings' | 'Bookings' | 'Messages' | 'Users' | 'Reviews', record: any): Promise<boolean> {
    if (!airtableConfig.token) return false;
    const bId = (airtableConfig.baseId || DEFAULT_BASE_ID).trim();
    const tok = airtableConfig.token.trim();
    const startTime = Date.now();

    try {
      let fields: any = {};
      if (table === 'Listings') fields = listingToAirtableFields(record);
      else if (table === 'Bookings') fields = bookingToAirtableFields(record);
      else if (table === 'Users') fields = userToAirtableFields(record);
      else if (table === 'Reviews') fields = reviewToAirtableFields(record);
      else if (table === 'Messages') fields = messageToAirtableFields(record);

      const tableName = this.getTableName(table);
      const url = `https://api.airtable.com/v0/${bId}/${encodeURIComponent(tableName)}`;
      
      const sendUpsert = async () => {
        return await fetch(url, {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${tok}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            performUpsert: { fieldsToMergeOn: ['id'] },
            records: [{ fields }],
            typecast: true
          })
        });
      };

      let res = await sendUpsert();

      if (!res.ok) {
        const errText = await res.text();
        if (errText.includes('Cannot update more than one record') || errText.includes('multiple times')) {
          await purgeAirtableTableDuplicates(bId, tok, tableName);
          res = await sendUpsert();
        }
      }

      const duration = Date.now() - startTime;
      if (res.ok) {
        addLog('AUTO_SYNC', 'success', tableName, duration, `Enregistrement ${record.id} (${table}) synchronisé en direct dans Airtable ${bId}`);
        return true;
      } else {
        const errText = await res.text();
        addLog('AUTO_SYNC', 'warning', tableName, duration, `Notice synchro Airtable (${res.status}): ${errText.slice(0, 150)}`);
        return false;
      }
    } catch (err: any) {
      console.warn(`Erreur auto-sync Airtable ${table}:`, err.message);
      addLog('AUTO_SYNC', 'error', table, Date.now() - startTime, `Exception réseau: ${err.message}`);
      return false;
    }
  },

  // Suppression unitaire synchronisée avec Airtable
  async triggerDeleteSync(table: 'Listings' | 'Bookings' | 'Messages' | 'Users' | 'Reviews', recordId: string): Promise<boolean> {
    if (!airtableConfig.token) return false;
    const bId = (airtableConfig.baseId || DEFAULT_BASE_ID).trim();
    const tok = airtableConfig.token.trim();
    const tableName = this.getTableName(table);
    const startTime = Date.now();

    try {
      // 1. Chercher l'ID interne Airtable (recXXXX) correspondant à l'identifiant id
      const findUrl = `https://api.airtable.com/v0/${bId}/${encodeURIComponent(tableName)}?filterByFormula=${encodeURIComponent(`{id} = '${recordId}'`)}&maxRecords=1`;
      const findRes = await fetch(findUrl, {
        headers: { 'Authorization': `Bearer ${tok}` }
      });
      if (!findRes.ok) return false;
      const data = await findRes.json();
      const airtableRecordId = data.records?.[0]?.id;

      if (airtableRecordId) {
        const delUrl = `https://api.airtable.com/v0/${bId}/${encodeURIComponent(tableName)}/${airtableRecordId}`;
        const delRes = await fetch(delUrl, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${tok}` }
        });
        if (delRes.ok) {
          addLog('AUTO_SYNC', 'success', tableName, Date.now() - startTime, `Enregistrement ${recordId} supprimé d'Airtable (${tableName})`);
          return true;
        }
      }
      return false;
    } catch (err: any) {
      console.warn(`Erreur suppression Airtable ${table}:`, err.message);
      return false;
    }
  },

  // Génération de CSV optimisé pour Airtable
  generateCsv(table: 'listings' | 'bookings' | 'users' | 'reviews' | 'messages'): string {
    const escapeCsv = (val: any) => {
      if (val === null || val === undefined) return '';
      const str = String(val);
      if (str.includes(',') || str.includes(';') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    if (table === 'listings') {
      const headers = ['id', 'title', 'price_per_night', 'commune', 'department', 'region', 'capacity', 'eco_labels', 'rating', 'status', 'host_name', 'images', 'description'];
      const rows = inMemoryListings.map(l => [
        escapeCsv(l.id),
        escapeCsv(l.title),
        escapeCsv(l.pricePerNight),
        escapeCsv(l.commune),
        escapeCsv(l.department),
        escapeCsv(l.region),
        escapeCsv(l.capacity),
        escapeCsv((l.labels || []).join('; ')),
        escapeCsv(l.rating),
        escapeCsv(l.status),
        escapeCsv(l.hostName),
        escapeCsv((l.images || []).join('\n')),
        escapeCsv(l.description)
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (table === 'bookings') {
      const headers = ['id', 'listing_id', 'listing_title', 'listing_commune', 'traveler_name', 'traveler_email', 'host_name', 'start_date', 'end_date', 'nights_count', 'guests_count', 'total_price', 'status', 'payment_status', 'access_code', 'co2_saved_kg', 'created_at'];
      const rows = inMemoryBookings.map(b => [
        escapeCsv(b.id),
        escapeCsv(b.listingId),
        escapeCsv(b.listingTitle),
        escapeCsv(b.listingCommune),
        escapeCsv(b.travelerName),
        escapeCsv(b.travelerEmail),
        escapeCsv(b.hostName),
        escapeCsv(b.startDate),
        escapeCsv(b.endDate),
        escapeCsv(b.nightsCount),
        escapeCsv(b.guestsCount),
        escapeCsv(b.totalPrice),
        escapeCsv(b.status),
        escapeCsv(b.paymentStatus),
        escapeCsv(b.accessCode),
        escapeCsv(b.co2SavedKg),
        escapeCsv(b.createdAt)
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (table === 'users') {
      const headers = ['id', 'name', 'email', 'role', 'phone', 'is_host_verified', 'is_email_verified', 'bio', 'avatar'];
      const rows = inMemoryUsers.map(u => [
        escapeCsv(u.id),
        escapeCsv(u.name),
        escapeCsv(u.email),
        escapeCsv(u.role),
        escapeCsv(u.phone),
        escapeCsv(u.isHostVerified),
        escapeCsv(u.isEmailVerified),
        escapeCsv(u.bio),
        escapeCsv(u.avatar)
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (table === 'reviews') {
      const headers = ['id', 'listing_id', 'traveler_name', 'rating', 'comment', 'created_at'];
      const rows = inMemoryReviews.map(r => [
        escapeCsv(r.id),
        escapeCsv(r.listingId),
        escapeCsv(r.travelerName),
        escapeCsv(r.rating),
        escapeCsv(r.comment),
        escapeCsv(r.createdAt)
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (table === 'messages') {
      const headers = ['id', 'booking_id', 'sender_id', 'sender_name', 'sender_role', 'content', 'timestamp'];
      const rows = inMemoryMessages.map(m => [
        escapeCsv(m.id),
        escapeCsv(m.bookingId),
        escapeCsv(m.senderId),
        escapeCsv(m.senderName),
        escapeCsv(m.senderRole),
        escapeCsv(m.content),
        escapeCsv(m.timestamp)
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    return '';
  },

  // Importer un lot de données fournies directement (JSON ou CSV paste)
  importRawData(tableName: string, data: any[]) {
    if (!Array.isArray(data) || data.length === 0) {
      return { success: false, message: 'Format invalide ou aucune ligne fournie' };
    }

    if (tableName.toLowerCase().includes('listing')) {
      const mapped = data.map(item => airtableFieldsToListing(item.fields || item, item.id));
      dbService.bulkUpsertListings(mapped);
    } else if (tableName.toLowerCase().includes('booking')) {
      const mapped = data.map(item => airtableFieldsToBooking(item.fields || item, item.id));
      dbService.bulkUpsertBookings(mapped);
    } else if (tableName.toLowerCase().includes('user')) {
      const mapped = data.map(item => ({
        id: item.id || item.fields?.id || `usr_${Date.now()}`,
        name: item.name || item.fields?.name || 'Utilisateur',
        email: item.email || item.fields?.email || '',
        role: item.role || item.fields?.role || 'voyageur',
        phone: item.phone || item.fields?.phone || '',
        isHostVerified: Boolean(item.is_host_verified || item.fields?.is_host_verified),
        isEmailVerified: Boolean(item.is_email_verified || item.fields?.is_email_verified),
        bio: item.bio || item.fields?.bio || '',
        avatar: item.avatar || item.fields?.avatar || '',
        createdAt: item.created_at || item.fields?.created_at || new Date().toISOString()
      }));
      dbService.bulkUpsertUsers(mapped);
    } else if (tableName.toLowerCase().includes('review')) {
      const mapped = data.map(item => ({
        id: item.id || item.fields?.id || `rev_${Date.now()}`,
        bookingId: item.booking_id || item.fields?.booking_id || item.bookingId || '',
        listingId: item.listing_id || item.fields?.listing_id || item.listingId || '',
        travelerId: item.traveler_id || item.fields?.traveler_id || item.travelerId || '',
        travelerName: item.traveler_name || item.fields?.traveler_name || item.travelerName || 'Voyageur',
        rating: Number(item.rating || item.fields?.rating) || 5,
        comment: item.comment || item.fields?.comment || '',
        createdAt: item.date || item.created_at || item.fields?.created_at || new Date().toISOString()
      }));
      dbService.bulkUpsertReviews(mapped);
    } else if (tableName.toLowerCase().includes('message')) {
      const mapped = data.map(item => airtableFieldsToMessage(item.fields || item, item.id));
      dbService.bulkUpsertMessages(mapped);
    }

    addLog('IMPORT', 'success', tableName, 10, `${data.length} enregistrements importés manuellement depuis Airtable`, data.length);
    return {
      success: true,
      message: `${data.length} lignes importées avec succès pour la table ${tableName}.`
    };
  }
};

// Purge automatique des doublons sur une table Airtable pour débloquer les contraintes d'upsert
async function purgeAirtableTableDuplicates(baseId: string, token: string, tableName: string) {
  try {
    const records = await fetchAllFromAirtable(baseId, token, tableName);
    const seen = new Set<string>();
    const toDelete: string[] = [];

    for (const r of records) {
      const id = r.fields?.id;
      if (!id || seen.has(id)) {
        toDelete.push(r.id);
      } else {
        seen.add(id);
      }
    }

    if (toDelete.length > 0) {
      for (let i = 0; i < toDelete.length; i += 10) {
        const chunk = toDelete.slice(i, i + 10);
        const query = chunk.map(id => `records[]=${encodeURIComponent(id)}`).join('&');
        await fetch(`https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}?${query}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
      }
    }
  } catch (err) {
    console.warn(`Notice nettoyage doublons ${tableName}:`, err);
  }
}

// Fonctions d'aide HTTP pour Airtable (batching max 10 par requête avec déduplication stricte)
async function batchUpsertToAirtable(baseId: string, token: string, tableName: string, records: { fields: any }[]): Promise<number> {
  // 1. Dédupliquer les enregistrements en mémoire par fields.id
  const uniqueMap = new Map<string, { fields: any }>();
  for (const r of records) {
    if (r.fields?.id) {
      uniqueMap.set(String(r.fields.id), r);
    }
  }
  const cleanRecords = Array.from(uniqueMap.values());
  if (cleanRecords.length === 0) return 0;

  const CHUNK_SIZE = 10;
  let totalCreated = 0;

  for (let i = 0; i < cleanRecords.length; i += CHUNK_SIZE) {
    const chunk = cleanRecords.slice(i, i + CHUNK_SIZE);
    const url = `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}`;

    const sendChunk = async () => {
      return await fetch(url, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          performUpsert: { fieldsToMergeOn: ['id'] },
          records: chunk,
          typecast: true // Cast automatique des strings vers les types Airtable
        })
      });
    };

    let res = await sendChunk();

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: { message: res.statusText } }));
      const msg = err.error?.message || `Erreur Airtable HTTP ${res.status}`;
      
      // Si Airtable signale des doublons sur la base distante, on purge les doublons et on réessaie automatiquement
      if (msg.includes('Cannot update more than one record') || msg.includes('multiple times in a single request')) {
        await purgeAirtableTableDuplicates(baseId, token, tableName);
        res = await sendChunk();
        if (!res.ok) {
          const retryErr = await res.json().catch(() => ({ error: { message: res.statusText } }));
          throw new Error(retryErr.error?.message || msg);
        }
      } else {
        throw new Error(msg);
      }
    }

    const data = await res.json();
    totalCreated += (data.records || []).length;
  }

  return totalCreated;
}

async function fetchAllFromAirtable(baseId: string, token: string, tableName: string): Promise<any[]> {
  const allRecords: any[] = [];
  let offset: string | undefined = undefined;

  do {
    const url: string = `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}${offset ? `?offset=${offset}` : ''}`;
    const res = await fetch(url, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: { message: res.statusText } }));
      throw new Error(err.error?.message || `Erreur HTTP ${res.status}`);
    }

    const data = await res.json();
    if (data.records) {
      allRecords.push(...data.records);
    }
    offset = data.offset;
  } while (offset);

  return allRecords;
}
