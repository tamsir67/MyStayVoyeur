import { useEffect, useState } from 'react';
import { Download, Share, X } from 'lucide-react';

// Bandeau « Installer l'application » (Android/Chrome/Edge) + aide pour iPhone/iPad
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const DISMISS_KEY = 'mystay_install_prompt_dismissed';

function readDismissed(): boolean {
  try { return localStorage.getItem(DISMISS_KEY) === '1'; } catch { return false; }
}

export function InstallAppPrompt() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [showIosHint, setShowIosHint] = useState(false);
  const [dismissed, setDismissed] = useState<boolean>(readDismissed);

  useEffect(() => {
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true;
    if (standalone || dismissed) return;

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', onPrompt);

    const ua = navigator.userAgent;
    const isIos = /iphone|ipad|ipod/i.test(ua) || (ua.includes('Macintosh') && 'ontouchend' in document);
    const isSafari = /safari/i.test(ua) && !/crios|fxios|edgios/i.test(ua);
    let timer: number | undefined;
    if (isIos && isSafari) timer = window.setTimeout(() => setShowIosHint(true), 4000);

    const onInstalled = () => setDeferred(null);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
      if (timer) window.clearTimeout(timer);
    };
  }, [dismissed]);

  const dismiss = () => {
    setDismissed(true);
    setDeferred(null);
    setShowIosHint(false);
    try { localStorage.setItem(DISMISS_KEY, '1'); } catch { /* ignore */ }
  };

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    const choice = await deferred.userChoice.catch(() => null);
    if (choice?.outcome === 'accepted') setDeferred(null);
    else dismiss();
  };

  if (dismissed || (!deferred && !showIosHint)) return null;

  return (
    <div
      role="dialog"
      aria-label="Installer l'application MyStay"
      className="fixed left-3 right-3 sm:left-auto sm:right-4 sm:w-[360px] z-[60] bg-white border border-[#DEDBD2] rounded-2xl shadow-xl p-3.5 flex items-start gap-3"
      style={{ bottom: 'calc(12px + env(safe-area-inset-bottom, 0px))' }}
    >
      <img src="/icons/icon-192.png" alt="" className="w-11 h-11 rounded-xl shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="font-bold text-sm text-stone-900">Installer MyStay</p>
        {deferred ? (
          <p className="text-xs text-stone-600 mt-0.5">Accédez à vos séjours depuis l’écran d’accueil, même avec une connexion faible.</p>
        ) : (
          <p className="text-xs text-stone-600 mt-0.5 flex flex-wrap items-center gap-1">
            Touchez <Share className="w-3.5 h-3.5 inline" aria-label="Partager" /> puis « Sur l’écran d’accueil ».
          </p>
        )}
        {deferred && (
          <button
            type="button"
            onClick={install}
            className="mt-2 inline-flex items-center gap-1.5 bg-[#243E36] text-white text-xs font-bold px-3 py-2 rounded-xl cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" /> Installer l’application
          </button>
        )}
      </div>
      <button
        type="button"
        onClick={dismiss}
        aria-label="Fermer"
        className="p-1.5 text-stone-500 hover:text-stone-800 rounded-lg cursor-pointer"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
